/* 
 * File:   main.cpp
 * Author: Grady Brill
 * Purpose: Lab, Military Budget
 * Created on June 23, 2015, 1:30 PM
 * Calculate the percentage of our budget allocated to the military. 
        Federal Budget: 3.9e12 
        Mil Budget: .589e12
 */
//System Libraries
#include <iostream>// I/O library 
using namespace std;
//Global Constants
//Prototype Functions
//Execution Begins Here!
int main(int argc, char** argv) {
//Declare Variables
    //FBudg= The federal budget
    //MBudg= The military Budget
    //PMFBudg= The Percentage the military/federal budget
    float FBudg, MBudg, PMFBudg;
    FBudg = 3.9e12;
    MBudg = 5.98e11;
    PMFBudg = MBudg/FBudg *100;
//Output the results
    cout<<"The Military budget is "<< PMFBudg <<endl;
    cout<<"percent of the Federal Budget"<< endl;
    return 0;
}

