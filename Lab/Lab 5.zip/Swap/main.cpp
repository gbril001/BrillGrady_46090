/*   
 * File:   main.cpp  
 * Author: Grady Brill  
 * Purpose: Lab, How To Swap 
 * Created on June 25, 2015, 10:23 AM  
 */  
//System Libraries  
#include <iostream>//I/O Library  
  
using namespace std; //namespace for iostream  
//User Libraries 
 
//Global Constants  
 
//Function Prototypes  
 
//Execution Begins Here!  
int main(int argc, char** argv) {  
//Declare Variables  
    int a,b;
    int min= 1;
    int max= 100;
//Input  values for a and b
    cout<< "Input 2 integer values between 1 and 99"<<endl;
    cin>>a>>b;
    //Validate the results
    if(a>=min && a <=max && b>=min && b<=max){
        //Prompt the user for which sw2ap
        cout<<"Which swap would you like to choose?"<<endl;
        cout<<"Storage ->s or in-place ->i"<<endl;
        //Declare the variable type
        char type;
        cin>>type;
        switch(type){
            case 's':{
                int temp=a;
                a=b;
                b=temp;
                break;
            }
            case 'i':{
                a=a^b;
                b=a^b;
                a=a^b;
                break;
            }
            default: cout<<"You don't follow instructions"<<endl;
        }
            //Output the results for the swap
    cout<<"old a = "<<b<<", new a = "<<a<<endl;
    cout<<"old b = "<<a<<", new b = "<<b<<endl;
        
    }else{
        cout<<"You don't follow instructions"<<endl;
        cout<<"No swap for you"<<endl;
    }
    return 0;  
} 
