/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Planning For Retirement 
 * Created on July 8, 2015, 10:46 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <fstream>
#include <iomanip>
#include <ctime>
#include <string>
#include <cstdlib>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
void heading(float year,float date,float savings, float invRate, float deposit);
void retirement(float salary,float pDep,float savings,
        float date, float year, float savReq, float invRate, float deposit);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float salary=90000;  //Average Salary
    float invRate=0.05f; //Investment Rate
    float savReq;        // Savings required for retirement
    float pDep=0.10f;    //Percentage to deposit each year(of gross not net)
    float deposit;       //Yearly deposit in $'s
    float savings=0;     //Initial Savings at start of employment
    float year=0;        //Start at year 0
    float date=15;
    savReq=salary/invRate;
    deposit=pDep*salary;

    //State the output
    heading(year, date,  savings, invRate,deposit);
    //Loop to calculate when retirement is possible and output the results
    retirement( salary, pDep, savings,date,year,savReq,invRate, deposit);
    return 0; 
}
//Outputs the heading for the variables calculated with void retirement
void heading(float year,float date, float savings, float invRate, float deposit){
//Display the heading
cout<<"Year       Date        Savings       Interest       Deposit"<<endl;
cout<<"___________________________________________________________"<<endl;
}
//Calculates how many years and the yearly deposit size to obtain the required
//savings amount needed in order to retire
void retirement(float salary,float pDep,float savings,
        float date, float year, float savReq, float invRate, float deposit){
do{
        savReq=salary/invRate;
        deposit=pDep*salary;// Deposit based salary
        savings*=(1+invRate);//Earned based upon investment rate
        savings+=deposit;//Add the deposit after earning investment rate
        year++;
        date++;
        cout<<fixed<<showpoint<<setprecision(2)<<endl;
        cout<<setw(4)<<static_cast<int>(year)<<"     "<<"06/01/"<<static_cast<int>(date)<<"   $"<<setw(8)<<
            savings<<"    "<<setw(11)<<invRate<<"     $"<<setw(8)<<deposit<<endl;
    }while(savings<savReq);   
}
