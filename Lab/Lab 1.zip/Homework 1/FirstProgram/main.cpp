/* 
 * File:   main.cpp
 * Author: Grady Brill
 * Created on June 22, 2015, 12:38 PM
 * Purpose: First Program
 */

//System Libraries 
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables Here
    float hours, rate, pay;
    
    //Input Variables Here
    hours=40;//Units =hours
    rate=10;//Units = $'s/hour
    //Process Input Here
    pay=hours*rate;//Units =$'s
    //Output Unknowns Here
    cout<<"Hours worked= "<<hours<<"(hrs)"<<endl;
    cout<<"Pay Rate    = $"<<rate<<"/(hrs)"<<endl;
    cout<<"My Paycheck =$"<<pay<<endl;
   
    //Exit Stage Right!

    return 0;
}
