/* 
 * File:   main.cpp
 * Author: Grady Brill
 * Created on June 22, 2015, 12:38 PM
 * Purpose: First Program to test the IDE
 */

//System Libraries 
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables Here
    
    //Input Variables Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"Hello World"<<endl;
    //Exit Stage Right!

    return 0;
}



