/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on July 2, 2015, 1:23 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

