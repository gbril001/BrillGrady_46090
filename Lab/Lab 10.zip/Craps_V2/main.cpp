/* 
/*     
 * File:   main.cpp    
 * Author: Grady Brill    
 * Purpose: Craps V2: Eventually to play craps
 * Created on July 7, 2015, 12:23 PM    
 */    
//System Libraries    
#include <iostream>//I/O Library  
#include <cmath>
#include <cstdlib>
#include <iomanip>
    
using namespace std; //namespace for iostream    
//User Libraries   
   
//Global Constants    
   
//Function Prototypes    
unsigned char roll(unsigned char,unsigned char);

//Execution Begins Here!    
int main(int argc, char** argv) {   
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
//Declare Variables   
    unsigned int nGames=36000;//roll die 6000 times
    unsigned int win=0, lose=0, playagn=0;
    int checksum;
//play the game
    for(int game=1;game<=nGames;game++){
        //int sum = roll(6,1);//six sided dice one time
        
        int sum = roll(6,2);
        switch(sum){
            case 1:playagn++;break;
            case 2:
            case 3:lose++;break;
            case 4:
            case 5:
            case 6:playagn++;break;
            case 7:win++;break;
            case 8:
            case 9:
            case 10:playagn++;break;
            case 11:win++;break;
            case 12:lose++;break;
            default:cout<<"Not Possible"<<endl;
        }
    }
    //Display the results
    cout<<"Out of "<<nGames<<" we win "<<setw(5)<<win<<" times"<<endl;
    cout<<"Out of "<<nGames<<" we lose "<<setw(5)<<lose<<" times"<<endl;
    cout<<"Out of "<<nGames<<" we roll again "<<setw(5)<<playagn<<" times"<<endl;
    checksum=win + lose+playagn;
    cout<<"Check Sum = "<<checksum<<endl;
    
    return 0;    
} 
unsigned char roll(unsigned char sides, unsigned char nDie){
    //Declare the sum of the die rolls
    unsigned char sum=0;
    
    //Loop for each die
    for(int thrw=1;thrw<=nDie;thrw++){
        sum+=(rand()%sides+1);
    }

    return sum;
}
