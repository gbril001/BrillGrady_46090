/* 
/*     
 * File:   main.cpp    
 * Author: Grady Brill    
 * Purpose: Craps V1: Eventually to play craps
 * Created on July 7, 2015, 12:23 PM    
 */    
//System Libraries    
#include <iostream>//I/O Library  
#include <cmath>
#include <cstdlib>
#include <iomanip>
    
using namespace std; //namespace for iostream    
//User Libraries   
   
//Global Constants    
   
//Function Prototypes    
unsigned char roll(unsigned char,unsigned char);

//Execution Begins Here!    
int main(int argc, char** argv) {   
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
//Declare Variables   
    unsigned int nGames=36000;//roll die 6000 times
    unsigned int s1=0, s2=0, s3=0, s4=0, s5=0, s6=0,
                 s7=0, s8=0, s9=0, s10=0, s11=0, s12=0;
    int checksum;
//play the game
    for(int game=1;game<=nGames;game++){
        //int sum = roll(6,1);//six sided dice one time
        
        int sum = roll(6,2);
        switch(sum){
            case 1:s1++;break;
            case 2:s2++;break;
            case 3:s3++;break;
            case 4:s4++;break;
            case 5:s5++;break;
            case 6:s6++;break;
            case 7:s7++;break;
            case 8:s8++;break;
            case 9:s9++;break;
            case 10:s10++;break;
            case 11:s11++;break;
            case 12:s12++;break;
            default:cout<<"Not Possible"<<endl;
             
        }
    }
    
    
    //Display the results
    cout<<"Out of "<<nGames<<" 1 was  thrown "<<setw(5)<<s1<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 2 was  thrown "<<setw(5)<<s2<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 3 was  thrown "<<setw(5)<<s3<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 4 was  thrown "<<setw(5)<<s4<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 5 was  thrown "<<setw(5)<<s5<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 6 was  thrown "<<setw(5)<<s6<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 7 was  thrown "<<setw(5)<<s7<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 8 was  thrown "<<setw(5)<<s8<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 9 was  thrown "<<setw(5)<<s9<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 10 was thrown "<<setw(5)<<s10<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 11 was thrown "<<setw(5)<<s11<<" times"<<endl;
    cout<<"Out of "<<nGames<<" 12 was thrown "<<setw(5)<<s12<<" times"<<endl;
    checksum= s1+ s2+ s3+ s4+ s5+ s6+s7 +s8+ s9+ s10+ s11+ s12;
    cout<<"Check Sum = "<<checksum<<endl;
    
    return 0;    
} 
unsigned char roll(unsigned char sides, unsigned char nDie){
    //Declare the sum of the die rolls
    unsigned char sum=0;
    
    //Loop for each die
    for(int thrw=1;thrw<=nDie;thrw++){
        sum+=(rand()%sides+1);
    }

    return sum;
}
