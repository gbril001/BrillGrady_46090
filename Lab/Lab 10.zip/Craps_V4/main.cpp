/* 
/*     
 * File:   main.cpp    
 * Author: Grady Brill    
 * Purpose: Craps V4: Eventually to play craps
 * Created on July 7, 2015, 12:23 PM    
 */    
//System Libraries    
#include <iostream>//I/O Library  
#include <cmath>
#include <cstdlib>
#include <iomanip>
    
using namespace std; //namespace for iostream    
//User Libraries   
   
//Global Constants    
   
//Function Prototypes    
unsigned char roll(unsigned char,unsigned char);
void plyCrap(unsigned int,unsigned int &,
        unsigned int &,unsigned int &);
void display(unsigned int,unsigned int ,
        unsigned int ,unsigned int, unsigned int );

//Execution Begins Here!    
int main(int argc, char** argv) {   
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
        //changes the start at the random number in the sequence
//Declare Variables   
    unsigned int nGames=36000;//roll die 6000 times
    unsigned int win=0, lose=0, playagn=0;
    int checksum=0;
 
//play the game
      plyCrap(nGames,win,lose,playagn);
//Display the results
      display(nGames,win,lose,playagn,checksum);
    
    return 0;    
} 
unsigned char roll(unsigned char sides, unsigned char nDie){
    //Declare the sum of the die rolls
    unsigned char sum=0;
    
    //Loop for each die
    for(int thrw=1;thrw<=nDie;thrw++){
        sum+=(rand()%sides+1);
    }

    return sum;
}
void display(unsigned int nGames,unsigned int win,
        unsigned int lose,unsigned int playagn, unsigned int checksum){
     //Display the results
    cout<<"Out of "<<nGames<<" we win  "<<setw(5)<<win<<" times"<<endl;
    cout<<"Out of "<<nGames<<" we lose "<<setw(5)<<lose<<" times"<<endl;
    cout<<"Out of "<<nGames<<" we roll again "<<setw(5)<<playagn<<" times"<<endl;
    checksum=win + lose;
    cout<<"Check Sum = "<<checksum<<endl;
}
void plyCrap(unsigned int nGames,unsigned int &win,
        unsigned int &lose,unsigned int &playagn){
        for(int game=1;game<=nGames;game++){
        //int sum = roll(6,1);//six sided dice one time
        
                int sum = roll(6,2);
                //roll the dice
                if(sum==7||sum==11)win++;//Winner
                else if (sum==2||sum==3||sum==12)lose++;//Looser
                else{
                //Roll again
                 playagn++;
                bool rollAgn=true;
                do{
                 int sum2=roll(6,2);
                        if(sum==sum2){
                        win++;
                        rollAgn=false;
                        }else if(sum2==7){
                        lose++;
                        rollAgn=false;
                        }       
                }while(rollAgn);
                }
        }
}