/* 
 * File:   main.cpp
 * Author: Grady Brill
 * Purpose: Create a program to solve for Gas Tax Percentage per Gallon
 * Created on June 24, 2015, 1:18 PM
 */
//System Library
#include <iostream>// I/O Library
using namespace std;// std namespace iostream
//User Libraries
//Global Constants
//Function Prototypes
//Execution Begins Here!

int main(int argc, char** argv) {
//Declare Variables Here
    float Tgal;// Total Gallon of Gas Price with ALL Taxes
    float Ftax;// Federal Tax per Gallon of Gas
    float CExtax;// Cal Ex Tax per Gallon of Gas
    float Pgas;// Pure Gallon of Gas Price
    float PSgas;// The Price of a Gallon of gas with just sales tax
    float Stax;// California Sales Tax
    float Ttax;// Total Tax per Gallon of Gas
    float PerTax;// The percentage of tax per price of gallon of gas
   
    cout << "The price of a Gallon of Gas at the pump is "<<"$";
        cin >> Tgal;
    cout << "The current Federal Sales Tax is "<<"$";
        cin >> Ftax;
    cout << "The current Cal Ex Tax is "<<"$";
        cin >> CExtax;
    cout << "The current Cal Sales Tax Percentage is "<<"%";
        cin >> Stax;
    PSgas = ((Tgal) - (Ftax) - (CExtax));
    Pgas = PSgas / (1 + Stax/100.0f);
    Ttax = Ftax + CExtax + Stax/100.0f;
    PerTax = (Ttax/Pgas)*100; 
    cout <<"The price of a gallon of gas with just sales tax is "<<PSgas<<"$"<< endl;
    cout <<"The pure price of just a gallon of gas is "<<Pgas <<"$"<< endl;
    cout <<"The percentage of tax per gallon of taxed gas is "<<PerTax<<"%"<< endl;
  
    return 0;
}

