/*     
 * File:   main.cpp    
 * Author: Grady Brill    
 * Purpose: Gaddis 6th Ed CH5 Problem 1: Sum of Numbers 
 * Created on July 10, 2015, 10:23 AM    
 */    
//System Libraries    
#include <iostream>//I/O Library 
#include <iomanip>
    
using namespace std; //namespace for iostream    
//User Libraries   
   
//Global Constants    
   
//Function Prototypes    
  void PrntAry( int a[],int b[],int n,int nCols);  
//Execution Begins Here!    
int main(int argc, char** argv) {    
//Declare Variables    
  const int SIZE=10;
  int n[SIZE]={1,2,3,4,5,6,7,8,9,10};
  int n2[SIZE];
//Output    
  for (int i=0;i<10;i++){
      n2[i]=n[i]*n[i];
  }
  cout<<"N    N^2"<<endl;
  cout<<"--------"<<endl;
  PrntAry(n,n2, SIZE, 1);
    return 0;    
}  
 void PrntAry(int a[], int b[],int n,int nCols){
    //Separate outputs with a line
    
    //Loop and output every element in the array
    for(int i=0;i<n;i++){
        cout<<a[i]<<" "<<setw(4)<<b[i];
        //When column is reached go to next line
        if((i%nCols)==(nCols-1))cout<<endl;
    }        
}


