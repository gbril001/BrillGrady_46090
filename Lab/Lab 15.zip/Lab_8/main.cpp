/*     
 * File:   main.cpp    
 * Author: Grady Brill    
 * Purpose: Lab 8
 * Created on July 10, 2015, 10:23 AM    
 */    
//System Libraries    
#include <iostream>//I/O Library    
#include <iomanip>
    
using namespace std; //namespace for iostream    
//User Libraries   
   
//Global Constants    
   
//Function Prototypes    
 void  GenAry1(int a[][12], const int n);
 void PrntAry(const int a[][12],const int n,int nCols);
//Execution Begins Here!    
int main(int argc, char** argv) {    
//Declare Variables    
    const int SIZE=12;
    int array[SIZE][SIZE];
//Output    
GenAry1(array, SIZE);
PrntAry(array, SIZE, 12);
    return 0;    
}  
void GenAry1(int a[][12], const int n){
    for (int i=0; i<12; i++){
        for(int j=0; j<12;j++){
            a[i][j]=((i+1)*(j+1));
            
        }}
}
void PrntAry(const int a[][12],const int n,int nCols){
    //Separate outputs with a line
    
    //Loop and output every element in the array
    for (int i=0; i<12; i++){
        for(int j=0; j<12;j++){
            cout<<setw(4)<<a[i][j];
            
        }cout<<endl;}
        //When column is reached go to next line
    }        