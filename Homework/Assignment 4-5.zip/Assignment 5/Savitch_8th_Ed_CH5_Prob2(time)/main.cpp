/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Savitch 8th Ed CH5 Prob2 (time)
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float ctime, wtime,ftime;
    float wtime1, wtime2;
    //current, wait, final times
    bool doAgain=true;
//Output   
    do{
    cout<<"What is the current time in 24 hour format?"<<endl;
    cin>>ctime;
    cout<<"What is the wait time in minutes?"<<endl;
    cin>>wtime;
    wtime1= (static_cast<int>(wtime)/60);
    wtime2=(static_cast<int>(wtime)%60);
    ftime= ctime+(wtime1*100)+wtime2;
    cout<<"After waiting the time will be "<<ftime<<endl;
   cout<<"Would you like to do it again? Enter y for yes or n for no.\n";
    char response;
    cin>>response;
    if (response=='y')doAgain=true;
    else doAgain=false;
        }while(doAgain);
    return 0;   
} 



