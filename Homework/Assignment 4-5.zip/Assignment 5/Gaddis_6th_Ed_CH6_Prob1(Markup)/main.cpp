/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 1: MarkUp
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  float RtMrkUP(float WhSlCst, float PctMrkUp);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float WhSlCst;//Wholesale Cost
    float PctMrkUp;//Percentage mark up
    float RtCost;//Retail Cost
//Output   
    cout<<"What is the wholesale cost of the item?"<<" $";
    cin>>WhSlCst;
    cout<<"What is the percentage mark up of the item?"<<" %";
    cin>>PctMrkUp;
    RtCost= RtMrkUP(WhSlCst, PctMrkUp);
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"The retail cost of the item is: $"<<RtCost<<endl;
    return 0;   
} 
//Function receives the wholesale cost and percentage mark up and 
//outputs the retail cost
float RtMrkUP(float WhSlCst, float PctMrkUp){
    float RtCost;
    RtCost= WhSlCst * ((PctMrkUp/100.0f)+1);
    return RtCost;
}

