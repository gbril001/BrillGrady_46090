/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 9: Present Value
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <cmath>
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  float Pvalue(float F, float r, float n);//Function that gives you the present value needed
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float P;//P is the present value in the account
    float F;//F is the future value in the account
    float r;//r is the annual interest rate
    float n;//n is the number of years
//Output   
    cout<<"What is the annual interest rate percentage of the account?"<<endl;
    cin>>r;
    cout<<"How many years will you leave the present deposit in the account?"<<endl;
    cin>>n;
    cout<<"What is the future balance in the account you would like?"<<endl;
    cin>>F;
    cout<<fixed<<showpoint<<setprecision(2);
    P=Pvalue(F, r, n);
    cout<<"The Present Value of the account needs to be $"<<P<<endl;
    return 0;   
} 
float Pvalue(float F, float r, float n){
    float P;
    P= F/(pow((1+(r/100.0f)),n));
    return P;
}

