/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 5: Falling Distance
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
#include <string>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
const float g=9.8;//Gravity in meters/s
//Function Prototypes   
float FallDst(float t);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float d;//Distance in meters
    float t=1;//Time in seconds
//Output
    do{
    d=FallDst(t);
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"The distance the object fell in "<<static_cast<int>(t)<<" second(s) is "<<d<<" meters."<<endl;
    t++;
    }while(t<=10);
    return 0;   
} 
float FallDst(float t){
    float d;
    d =(1/2.0f)*(g)*(t*t);
    return d;
}