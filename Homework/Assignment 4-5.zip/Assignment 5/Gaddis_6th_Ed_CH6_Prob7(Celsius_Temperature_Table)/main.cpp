/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 7: Celsius Temperature Table
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   

//Function Prototypes   
float Conv2C(float F);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float C;//The temperature in Celsius
    float F=0;//The temperature in Fahrenheit
//Output
    cout<<"Fahrenheit -> Celsius"<<endl;
    cout<<"---------------------"<<endl;
    do{
    C= Conv2C(F);
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<setw(10)<<F<<setw(11)<<C<<endl;
    F++;
    }while(F<=20);
    return 0;   
} 
float Conv2C(float F){
    float C;
    C = (5/9.0f)*(F-32.0f);
    return C;
}

