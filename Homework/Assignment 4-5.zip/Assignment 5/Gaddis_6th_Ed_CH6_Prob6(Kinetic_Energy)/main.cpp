/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 6: Kinetic Energy
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   

//Function Prototypes   
float KinEng(float m,float v);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float m;//Mass in kilograms
    float v;//The velocity in meters per seconds 
    float KE;//The Kinetic Energy
//Output
    cout<<"What is the mass of the object in kilograms?"<<endl;
    cin>>m;
    cout<<"What is the objects velocity in meters per second?"<<endl;
    cin>>v;
    KE=KinEng(m ,v);
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"The objects kinetic energy is "<<KE<<" Joules."<<endl;
    
    return 0;   
} 
float KinEng(float m,float v){
    float KE;
    KE =(1/2.0f)*(m)*(v*v);
    return KE;
}

