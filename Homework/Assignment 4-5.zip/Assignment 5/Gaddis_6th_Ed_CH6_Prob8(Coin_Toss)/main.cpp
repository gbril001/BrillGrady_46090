/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 8: Coin Toss
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
#include <ctime>
#include <cstdlib>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   

//Function Prototypes   
void CoinTss(int flip1);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float flip;//Inputed number of tosses
    int flip1=1;//Loop flip
    int cointss;//The random coin toss function
    float heads;
     float tails;
    float PctHds;//Percentage it hit heads
    float PctTls;//Percentage it hit tails
    srand(static_cast<unsigned int>(time(0)));
//Output
    cout<<"How many times would you like to toss the coin?"<<endl;
    cin>>flip;
    do{
    CoinTss(flip1);
    flip1++;
    }while(flip1<=flip);
    PctHds= (heads/flip)*100.0f;
    PctTls= (tails/flip)*100.0f;
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"The coin landed on Heads "<<PctHds<<"% of the time"<<endl;
    cout<<"The coin landed on Tails "<<PctTls<<"% of the time"<<endl;
    return 0;   
} 
//Function that gives you heads or tails randomly
 void CoinTss(int flip1){
     int cointss;
     float heads;
     float tails;
    cointss= (rand()%2+1);
     if (cointss==1){
         cout<<"Toss "<<flip1<<" is Heads"<<endl;}
     else if(cointss==2){
         cout<<"Toss "<<flip1<<" is Tails"<<endl;}
     
}