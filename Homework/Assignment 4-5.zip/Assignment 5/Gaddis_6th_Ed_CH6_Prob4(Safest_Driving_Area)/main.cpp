/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 4: Safest Driving Area
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
#include <string>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  int NumAcc(char input);
  void LowAcc(int NAcc,int SAcc, int EAcc,int WAcc, int CAcc);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    string Divsion;
    string Ndiv="North";
    string Sdiv="South";
    string Ediv="East";
    string Wdiv="West";
    string Cdiv="Central";
    int NAcc;
    int SAcc;
    int EAcc;
    int WAcc;
    int CAcc;
    char input;
    int entry=0;
    bool doAgain=true;
    char response;
//Output
    cout<<"What region would you like to enter the number of accidents for?"<<endl;
    cout<<"Enter N(for North), S(for South), E(for East), W(for West), or C(for Central)."<<endl;
    do{
    cin>>input;
    
    if (input=='N'){
        cout<<Ndiv<<endl;
        NAcc=NumAcc(input);}
    if (input=='S'){
        cout<<Sdiv<<endl;
        SAcc=NumAcc(input);}
    if (input=='E'){
        cout<<Ediv<<endl;
        EAcc=NumAcc(input);}
    if (input=='W'){
        cout<<Wdiv<<endl;
        WAcc=NumAcc(input);}
    if (input=='C'){
        cout<<Cdiv<<endl;
        CAcc=NumAcc(input);}
    cout<<"Would you like to enter another division's accident total? y/n? ";
    cin>>response;
    if(response=='y') {
        cout<<"Enter N(for North), S(for South), E(for East), W(for West), or C(for Central)."<<endl;
        doAgain=true;}
    else {
        doAgain=false;}
    }while(doAgain);
    
   LowAcc(NAcc,SAcc,EAcc,WAcc, CAcc);
    return 0;   
} 
//Function receives the wholesale cost and percentage mark up and 
//outputs the retail cost
int NumAcc(char input){
    int QtSales1;//Inputed number or automobile accidents for N
    int QtSales2;//Inputed number or automobile accidents for S
    int QtSales3;//Inputed number or automobile accidents for E
    int QtSales4;//Inputed number or automobile accidents for W
    int QtSales5;//Inputed number or automobile accidents for C
    int NAcc;//outputed number of automobile accidents for N
    int SAcc;//outputed number of automobile accidents for S
    int EAcc;//outputed number of automobile accidents for E
    int WAcc;//outputed number of automobile accidents for W
    int CAcc;//outputed number of automobile accidents for C
    if(input=='N'){
        cout<<"What is the number of automobile accidents?"<<endl;
        cin>>QtSales1; 
        return QtSales1;}
    if(input=='S'){
        cout<<"What is the number of automobile accidents?"<<endl;
        cin>>QtSales2; 
        return QtSales2;}
    if(input=='E'){
        cout<<"What is the number of automobile accidents?"<<endl;
        cin>>QtSales3; 
        return QtSales3;}
    if(input=='W'){
        cout<<"What is the number of automobile accidents?"<<endl;
        cin>>QtSales4; 
        return QtSales4;}
    if(input=='C'){
        cout<<"What is the number of automobile accidents?"<<endl;
        cin>>QtSales5; 
        return QtSales5;}
    
}
void LowAcc(int NAcc,int SAcc, int EAcc,int WAcc, int CAcc){
     string Ndiv="North";
    string Sdiv="South";
    string Ediv="East";
    string Wdiv="West";
    string Cdiv="Central";
    if ((NAcc< SAcc) && (NAcc< EAcc) && (NAcc<WAcc) && (NAcc<CAcc))
        cout<<"The "<<Ndiv<<" division had the lowest number of accidents with "<<NAcc<<" accidents."<<endl;
    if ((SAcc< NAcc) && (SAcc<EAcc) && (SAcc<WAcc) && (SAcc<CAcc))
        cout<<"The "<<Sdiv<<" division had the lowest number of accidents with "<<SAcc<<" accidents."<<endl;
    if ((EAcc< NAcc) && (EAcc<SAcc) && (EAcc<WAcc) &&(EAcc<CAcc))
        cout<<"The "<<Ediv<<" division had the lowest number of accidents with "<<EAcc<<" accidents."<<endl;
    if ((WAcc< NAcc) && (WAcc<SAcc) && (WAcc<EAcc) && (WAcc<CAcc))
        cout<<"The "<<Wdiv<<" division had the lowest number of accidents with "<<WAcc<<" accidents."<<endl;
    if ((CAcc< NAcc) && (CAcc<SAcc) && (CAcc<EAcc) && (CAcc<WAcc))
        cout<<"The "<<Cdiv<<" division had the fewest accidents with only "<<CAcc<<" accidents."<<endl;
}
