/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH6 Problem 3: Winning Division
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library 
#include <iomanip>
#include <string>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  int GetSale(int input);
  void HighSls(int NEsales, int SEsales, int NWsales, int SWsales);
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    string Divsion;
    string NEdiv="Northeast";
    string SEdiv="Southeast";
    string NWdiv="Northwest";
    string SWdiv="Southwest";
    int NEsales;
    int SEsales;
    int NWsales;
    int SWsales;
    int input;
    int QtSales1;
    int entry=0;
    bool doAgain=true;
    char response;
//Output
    cout<<"What division would you like to enter the Quarterly Sales for?"<<endl;
    cout<<"Enter 1(for NE), 2(for SE), 3(for NW), or 4(for SW)"<<endl;
    do{
    cin>>input;
    
    if (input==1){
        cout<<NEdiv<<endl;
    NEsales=GetSale(input);}
    if (input==2){
        cout<<SEdiv<<endl;
    SEsales=GetSale(input);}
    if (input==3){
        cout<<NWdiv<<endl;
    NWsales=GetSale(input);}
    if (input==4){
        cout<<SWdiv<<endl;
    SWsales=GetSale(input);}
    cout<<"Would you like to enter another Quarterly Sales? y/n? ";
    cin>>response;
    if(response=='y') {
        cout<<"Enter 1(for NE), 2(for SE), 3(for NW), or 4(for SW)\n";
        doAgain=true;}
    else {
        doAgain=false;}
    }while(doAgain);
    
   HighSls(NEsales,SEsales,NWsales,SWsales);
    return 0;   
} 
//Function receives the wholesale cost and percentage mark up and 
//outputs the retail cost
int GetSale(int input){
    int QtSales1;
    int QtSales2;
    int QtSales3;
    int QtSales4;
    if(input<2 && input>0){
        cout<<"What is the Quarterly Sales?"<<" $";
        cin>>QtSales1; 
        return QtSales1;}
    if(input<<3 && input>>1){
        cout<<"What is the Quarterly Sales?"<<" $";
        cin>>QtSales2; 
        return QtSales2;}
    if(input<<4 && input>>2){
        cout<<"What is the Quarterly Sales?"<<" $";
        cin>>QtSales3; 
        return QtSales3;}
    if(input<<5 && input>>3){
        cout<<"What is the Quarterly Sales?"<<" $";
        cin>>QtSales4; 
        return QtSales4;}
    
}
void HighSls(int NEsales, int SEsales, int NWsales, int SWsales){
    string NEdiv="Northeast";
    string SEdiv="Southeast";
    string NWdiv="Northwest";
    string SWdiv="Southwest";
    if ((NEsales> SEsales) && (NEsales> NWsales) && (NEsales>SWsales))
        cout<<"The "<<NEdiv<<" division had the highest sales with: $"<<NEsales<<endl;
    if ((SEsales> NEsales) && (SEsales>NWsales) && (SEsales>SWsales))
        cout<<"The "<<SEdiv<<" division had the highest sales with: $"<<SEsales<<endl;
    if ((NWsales> SEsales) && (NWsales>NEsales) && (NWsales>SWsales))
        cout<<"The "<<NWdiv<<" division had the highest sales with: $"<<NWsales<<endl;
    if ((SWsales> SEsales) && (SWsales>NWsales) && (SWsales>NEsales))
        cout<<"The "<<SWdiv<<" division had the highest sales with: $"<<SWsales<<endl;
}
