/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 1: Sum of Numbers
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    int input;
    int min = 0;
    int sum=0;
    bool doAgain=true;
//Output   
    do{
    cout<<"Enter a postive integer value: "<<endl;
    cin>>input;
    if (input<0)
        cout<<"You did not input a positive integer value!"<<endl;
    else if (input>0){
        do{
           sum = sum + min ;
           min++;
        }while(min<=input);
        cout<<"The sum is "<<sum<<endl;
    }
  cout<<"Would you like to do it again? Enter y for yes or n for no.\n";
    char response;
    cin>>response;
    if (response=='y')doAgain=true;
    else doAgain=false;
        }while(doAgain);
    
    return 0;   
} 

