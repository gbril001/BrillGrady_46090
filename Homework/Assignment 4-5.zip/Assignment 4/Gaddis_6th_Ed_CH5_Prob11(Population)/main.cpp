/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 11: Population
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float IntPop;//Initial Population
    float IncPop;//Increased population by IncPop
    float Npop;//New Population size
    float IncPct;//Daily increase percentage
    float Ndays;//Number of days of increase
    int day=1;//loop day
    //average daily population increase
    
//Output   
    do{
    cout<<"What is the size of the starting population?"<<endl;
    cin>>IntPop;
    if (IntPop<2)
        cout<<"Please enter a starting population size of at least 2."<<endl;
    }while(IntPop<2);
    do{
    cout<<"What is the daily population increase percentage?"<<endl;
    cin>>IncPct;
    if(IncPct<0)
        cout<<"Please enter a positive population increase percentage (ex:4%)."<<endl;
    }while(IncPct<0);
    do{
    cout<<"What is the number of days the organisms will multiply?"<<endl;
    cin>>Ndays;
    if(Ndays<1)
        cout<<"Please enter at least 1 day for the "
                "number of days the organisms will multiply"<<endl;
    }while(Ndays<1);
    cout<<"The initial size population is "<<IntPop<<" organisms."<<endl;
    do{ 
        IncPop= IntPop*((IncPct/100.0f));
        Npop=IncPop+IntPop;
        IntPop=Npop;
        cout<<"The population size after "<<day<<" day  is "<<static_cast<int>(IntPop)<<" organisms."<<endl;
        day++;
    }while(day<=Ndays);
    return 0;   
}

