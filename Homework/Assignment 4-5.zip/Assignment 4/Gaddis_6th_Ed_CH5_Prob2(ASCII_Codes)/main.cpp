/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 1: Sum of Numbers
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>

   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    int num=0;
    int var=0;
    char ascii;

//Output   
    do{
        cout<<ascii;
        num++,ascii++;
        if (num%16==15)
            cout<<endl;
    }while(num<=127);
    
    return 0;   
} 