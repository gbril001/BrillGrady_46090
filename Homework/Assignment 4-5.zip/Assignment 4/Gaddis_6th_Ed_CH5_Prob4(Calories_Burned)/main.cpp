/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 4: Calories Burned
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float CalBurn=0;
    int min=0;
//Output   
    cout<<"Minutes Running  Calories Burned"<<endl;
    cout<<"________________________________"<<endl;
    do{
        cout<<setw(15)<<min<<setw(17)<<fixed<<showpoint<<setprecision(2)<<CalBurn<<endl;
        min+=5;
        CalBurn+=5*(3.9);
    }while(min<=30);
    return 0;   
} 

