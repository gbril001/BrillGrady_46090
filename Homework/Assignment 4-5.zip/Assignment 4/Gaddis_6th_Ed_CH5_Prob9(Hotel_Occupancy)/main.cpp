/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 9: Hotel Occupancy
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    int Nfloors, Nroom, Nocc, Nunocc;
    float PctOcc;
    int floor=1;//loop floor
    // Number of floors
    //Number of Rooms
    //Number or occupied rooms
    //Number of unoccupied rooms
    
//Output   
    cout<<"How many floors are there?"<<endl;
    cin>>Nfloors;
    
    do{
    cout<<"How many rooms are there on floor "<<floor<<" ?"<<endl;
    cin>>Nroom;
    cout<<"How many of the rooms are occupied?"<<endl;
    cin>>Nocc;
    Nroom+=Nroom;
    Nocc+=Nocc;
    floor++;
    if(floor==13) floor++;
    }while(floor<=Nfloors);
    Nunocc= Nroom - Nocc;
    PctOcc= (Nocc/static_cast<float>(Nroom))*100;
    cout<<"Rooms  Occupied  Unoccupied  % Occupied"<<endl;
    cout<<"---------------------------------------"<<endl;
    cout<<setw(2)<<Nroom<<setw(10)<<Nocc<<setw(12)<<
            Nunocc<<setw(11)<<PctOcc<<"%"<<endl;
    return 0;   
}


