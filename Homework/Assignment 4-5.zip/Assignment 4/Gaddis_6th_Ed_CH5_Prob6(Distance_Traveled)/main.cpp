/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 6:Distance Traveled
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    int hour1;//inputed total hours
    int hour=1;//loop hours
    float speed;
    float dist=0;//distance train travels in xHours at ySpeed
//Output   
    cout<<"What is the speed of the vehicle in miles per hour?"<<endl;
    cin>>speed;
    cout<<"How many hours has the vehicle been moving at this speed?"<<endl;
    cin>>hour1;
    cout<<"Hour  Distance Traveled"<<endl;
    cout<<"---------------------"<<endl;
    do{
        dist= speed * hour;
        cout<<setw(4)<<hour<<setw(12)<<dist<<endl;
        hour++;
    }while(hour<=hour1);
    return 0;   
}