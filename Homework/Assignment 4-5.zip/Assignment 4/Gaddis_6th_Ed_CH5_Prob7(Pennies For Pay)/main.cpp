/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 7:Pennies for Pay
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float Ndays;//Total number of days worked
    float DPay=1;//Total pay per day
    int day=1;//The current day
    float TPay;//Total Pay
    bool doAgain=true;
    
//Output   
   
    do{cout<<"How many whole days did you work?"<<endl;
        cin>>Ndays;
        if(Ndays<1){
            cout<<"That was not a whole day. Try Again."<<endl;}
    }while(Ndays<1);
  
    cout<<"Days Worked  Pay Per Day"<<endl;
    cout<<"------------------------"<<endl;
    do{
        cout<<setw(10)<<day<<setw(4)<<"$"<<setw(9)
                <<fixed<<showpoint<<setprecision(2)<<DPay/100<<endl;
        day++;
        TPay=TPay+(DPay/100);
        DPay+=DPay;
    }while(day<=Ndays);
    cout<<"The Total Pay for "<<static_cast<int>(Ndays)<<" days worked is $"
            <<fixed<<showpoint<<setprecision(2)<<TPay<<endl;
    return 0;   
}
