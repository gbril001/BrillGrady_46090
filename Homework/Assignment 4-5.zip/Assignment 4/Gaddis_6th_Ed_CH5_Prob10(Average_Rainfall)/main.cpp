/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 10: Average Rainfall
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    float years;//how many years we're calculating
    int year=1;//loop year
    int months=12;
    int month=1;//loop month
    float rain;//inches of rain per month
    float Rain=0;//The sum of inches of rain
    float Nmonths;//Total number of months
    float AvgRain;//Average rainfall per month
    
    
//Output   
 do{
    cout<<"What is the number of years we are calculating the average rainfall for?"<<endl;
    cin>>years;
     if(years<1){
     cout<<"Please enter at least 1 year. Try Again."<<endl;}
    }while(years<1);
    
    do{if (month==13)
       month=month-12;
    
        do{
            do{
                cout<<"How many inches of rain fell during month "<<month<<" of year "<<year<<endl;
                cin>>rain;
                if (rain<0){
                cout<<"There can't be negative rainfall. Try Again."<<endl;}
            }while(rain<0);
          Rain+=rain;
          month++;
       }while(month<=months);
     year++;
  }while(year<=years);
    Nmonths=(years*12.0f);
    AvgRain= Rain/(Nmonths);
    cout<<"Months  Inches of Rain  Avg Monthly Rain"<<endl;
    cout<<"----------------------------------------"<<endl;
    cout<<setw(6)<<Nmonths<<setw(16)<<fixed<<showpoint<<setprecision(2)<<
            Rain<<setw(16)<<AvgRain<<endl;
    return 0;   
}
