/*    
 * File:   main.cpp   
 * Author: Grady Brill   
 * Purpose: Gaddis 6th Ed CH5 Problem 5: Membership Fee Increase
 * Created on July 10, 2015, 10:23 AM   
 */   
//System Libraries   
#include <iostream>//I/O Library   
#include <iomanip>
   
using namespace std; //namespace for iostream   
//User Libraries  
  
//Global Constants   
  
//Function Prototypes   
  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
    int Mfee=2500;
    float IncFee=0.04;
    int year=2015;
//Output   
    cout<<"Year  Membership Fee"<<endl;
    cout<<"********************"<<endl;
    do{
        cout<<setw(4)<<year<<setw(9)<<"$"<<setw(6)<<Mfee<<endl;
        Mfee+=(Mfee*IncFee);
        year++;
    }while(year<=2021);
    return 0;   
}