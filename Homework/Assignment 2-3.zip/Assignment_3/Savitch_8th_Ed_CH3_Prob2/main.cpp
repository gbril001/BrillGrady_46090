/*       
 * File:   main.cpp      
 * Author: Grady Brill      
 * Purpose: Savitch 8th Ed CH3 Prob2  
 * Created on July 2, 2015, 12:55 PM      
 */      
//System Libraries      
#include <iostream>//I/O Library 
#include <iomanip>
  
using namespace std; //namespace for iostream      
//User Libraries     
     
//Global Constants      
     
//Function Prototypes      
     
//Execution Begins Here!      
int main(int argc, char** argv) {      
//Declare Variables      
    bool doAgain= true;
    float AccBal;//Account Balance
    float TAmoDue;//Total amount due
    float minpay;//Minimum payment due
      
//Output the results  
    do{  
        cout<<"What is the account balance?"<<endl;
        cin>>AccBal;
        if (AccBal>1000){
            TAmoDue= ((AccBal-1000)*1.01)+(1000*1.015);}
        else{
            TAmoDue= (AccBal*1.015);}
        cout<<fixed<<showpoint<<setprecision(2)<<endl;
        cout<<"The total amount due is $"<<TAmoDue<<endl;
        if ((TAmoDue)<10.0){
            minpay=TAmoDue;
        }
        if((TAmoDue)>10.0){
            if (((TAmoDue)*0.1f)>10){
                minpay=(TAmoDue*0.1);}
            if(10>((TAmoDue)*0.10)){
                minpay=10;}
        }
        cout<<"The minimum payment due is $"<<minpay<<endl;
           cout<<"Would you like to do it again? Enter y for yes or n for no.\n";   
           char response;   
           cin>>response;   
           if (response=='y')doAgain=true;   
           else doAgain=false;   
           }while(doAgain);  
    return 0;      
}

