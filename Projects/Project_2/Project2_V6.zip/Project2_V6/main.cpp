/*   
* File: main.cpp   
* Author: Grady Brill   
* Purpose:Project2_V6  
* Created on July 10, 2015, 10:23 AM   
*/   
//System Libraries   
#include <iostream>//I/O Library   
#include <cstdlib>   
#include <ctime>   
#include <string>   
#include <algorithm>  
#include <vector>  
#include <fstream> 
#include <iomanip> 
   
using namespace std; //namespace for iostream   
//User Libraries   
   
//Global Constants   
   
//Function Prototypes   
int FstCds(vector<string> d, int i, int j);  
void PlPlay(vector<string> d, int &S, char C,int &l);  
void DlPlay(vector<string> D, int &S, int &w,int &Dlsum);  
void GameDis(int &S, int &D, int &l,int &w, int &p);  
void Score(int &l, int &w, int &p); 
void sort(string a[], int b);  
//Execution Begins Here!   
int main(int argc, char** argv) {   
//Declare Variables   
char choice;  
const int Size=13; 
const int size=4; 
int SIZE=52;  
int Sum, DlSum;  
vector<string> deck;  
string Deck[SIZE]; 
string base[Size] = {"2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace"};   
string suit[size] = {"Diamonds", "Hearts", "Spades", "Clubs"};  
int L=0; 
int W=0; 
int P=0; 
bool doAgain=true; 
//Set the Random Time Seed  
srand(static_cast<unsigned int>(time(0))); 
do{ 
//Call the string base[] and string suit[] 
// Open the file for output in binary mode. 
fstream file; 
file.open("binary.dat", ios::out | ios::binary); 
file.write(reinterpret_cast<char *>(base), sizeof(base)); 
file.close(); 
file.open("binary.dat", ios::in | ios::binary); 
file.read(reinterpret_cast<char *>(base), sizeof(base)); 
////Output the binary inputed and read string base[] 
//for (int i=0; i<Size;i++) 
//    cout<<base[i]<<" "; 
//    cout<<endl; 
file.close(); 
 
 
//Fill the deck  
for(int i = 0; i <(4); ++i) {  
for(int j =0; j <(13); ++j)   
deck.push_back(base[j]);}   
  
  
  
//Shuffle the deck 
 random_shuffle(deck.begin(),deck.end()); 
  
        //Show deck is shuffled 
//        for(int i=0;i<SIZE;i++) 
//            cout<<deck[i]<<" "; 
//        cout<<endl; 
  
        //Set the deck(vector) equal to Deck(array) to pass through sort function 
        for(int i=0;i<SIZE;i++) 
            Deck[i]=deck[i]; 
//Sort the deck(vector) to show knowledge of sorting and include in project 
sort(Deck,SIZE);  
 for(int i=0;i<SIZE;i++) 
     deck[i]=Deck[i]; 
        //Show that the deck(vector) is sorted 
//        for(int i=0;i<SIZE;i++) 
//        cout<<deck[i]<<" "; 
//        cout<<endl; 
//Shuffle the deck again for play use 
 random_shuffle(deck.begin(),deck.end()); 
//         for(int i=0;i<SIZE;i++) 
//        cout<<deck[i]<<" "; 
//        cout<<endl; 
  
//Output the play  
cout<<"Your cards are "<<deck[0]<<" and "<<deck[1]<<endl;  
Sum=FstCds(deck, 0, 2);  
if (Sum==21){   
    cout<<"You got BlackJack!"<<endl;   
    cout<<"The Dealer checks their cards for BlackJack."<<endl;   
        if (DlSum==21)   
            cout<<"The Dealer had a BlackJack too! You push!"<<endl;   
        else{ cout<<"The Dealer doesn't have a BlackJack! You Win!"<<endl; 
        W++; 
        }}  
if (Sum!=21){  
    cout<<"Your total is "<<Sum<<endl;   
    cout<<"The dealer is showing a "<<deck[27]<<endl;  
        if(deck[27]=="10" ||deck[27]=="Jack" ||deck[27]=="Queen" ||deck[27]=="King" ||deck[27]=="Ace"){  
                 DlSum=FstCds(deck, 27,29);  
                cout<<"The Dealer checks their cards for a BlackJack"<<endl;   
            if (DlSum==21){   
                cout<<"Uh-Oh! The Dealer's other card was a "<<deck[28]<<endl;   
                cout<<"The Dealer got a BlackJack! You lose!"<<endl;  
                L++;}   
            else if(DlSum!=21) cout<<"The Dealer doesn't have a BlackJack."<<endl;   
           }  
        if(DlSum!=21 && Sum!=21){  
            cout<<"Would you like to hit or stay? Enter 'h' for hit or 's' for stay."<<endl;  
            cin>>choice;  
            PlPlay(deck,Sum, choice,L);  
            DlPlay(deck,Sum,W,DlSum);  
            GameDis(Sum,DlSum, L, W, P);} 
            }  
 
 
//End the do while by asking if they want to play again   
cout<<endl;   
char response;   
do{   
    cout<<"Would you like to play again? Enter y for yes or n for no.\n";   
    cin>>response;   
    //Prevent other characters from being entered aka fail safe   
    if (response=='y'||response=='n')   
        {doAgain=false;}   
    else{   
        doAgain=true;   
        }   
}while(doAgain);   
    if (response=='y')doAgain=true;   
    else doAgain=false;   
}while(doAgain);  
cout<<"L:"<<L<<" W:"<<W<<" P:"<<P<<endl; 
Score(L, W, P); 
//Read in file concept   
//After finished playing outputs "Thanks For Playing!!!"   
ifstream input;   
string thanks;   
input.open("TFP.dat");   
while(!input.eof()){   
input>>thanks;   
cout<<thanks<<" ";}   
return 0;   
}   
  
//first two cards  
int FstCds(vector<string> d, int i, int j){  
int S=0;  
for (i; i<j;i++){  
if (d[i]=="2")  
S+=2;  
else if (d[i]=="3")  
S+=3;  
else if (d[i]=="4")  
S+=4;  
else if (d[i]=="5")  
S+=5;  
else if (d[i]=="6")  
S+=6;  
else if (d[i]=="7")  
S+=7;  
else if (d[i]=="8")  
S+=8;  
else if (d[i]=="9")  
S+=9;  
else if (d[i]=="10"||d[i]=="Jack"||d[i]=="Queen"||d[i]=="King")  
S+=10;  
else if (d[i]=="Ace")  
S+=11;}  
return S;  
}  
 
 
//Player PLay 
void PlPlay(vector<string> d, int &S, char C, int &l){  
if (C=='h'){  
int i=2;  
do{   
cout<<"You got a "<<d[i]<<endl;  
if (d[i]=="2")  
S+=2;  
else if (d[i]=="3")  
S+=3;  
else if (d[i]=="4")  
S+=4;  
else if (d[i]=="5")  
S+=5;  
else if (d[i]=="6")  
S+=6;  
else if (d[i]=="7")  
S+=7;  
else if (d[i]=="8")  
S+=8;  
else if (d[i]=="9")  
S+=9;  
else if (d[i]=="10"||d[i]=="Jack"||d[i]=="Queen"||d[i]=="King")  
S+=10;  
else if (d[i]=="Ace")  
S+=11;  
   
if(S<=21){  
cout<<"Your total is "<<S<<endl;}  
else if(S>21 && (d[0]=="Ace"||d[1]=="Ace"||d[i]=="Ace")){  
S-=10;  
cout<<"Your total is "<<S<<endl;}  
else if (S>21){  
cout<<"Your total is "<<S<<endl;  
cout<<"You went over 21! You busted!!!"<<endl; 
l++;}  
if(S<=21){  
cout<<"Would you like to hit or stay? Enter 'h' for hit or 's' for stay."<<endl;  
cin>>C;}  
i++;  
}while((C=='h')&&(S<=21));}   
} 
 
 
//Dealer Play 
void DlPlay(vector<string> D, int &S, int &w,int &Dlsum){   
Dlsum=FstCds(D, 27,29);  
cout<<"The Dealer has a "<<D[27]<<" and "<<D[28]<<endl;  
cout<<"The Dealer's total is "<<Dlsum<<endl;  
if(Dlsum>17 && Dlsum<21)  
cout<<"The dealer stays"<<endl;  
if(Dlsum==21)  
cout<<"The Dealer got a BlackJack!"<<endl;  
if (S<=21 && Dlsum<17){  
int i=29;  
do{ cout<<"The Dealer must hit"<<endl;  
cout<<"The Dealer got a "<<D[i]<<endl;  
if (D[i]=="2")  
Dlsum+=2;  
else if (D[i]=="3")  
Dlsum+=3;  
else if (D[i]=="4")  
Dlsum+=4;  
else if (D[i]=="5")  
Dlsum+=5;  
else if (D[i]=="6")  
Dlsum+=6;  
else if (D[i]=="7")  
Dlsum+=7;  
else if (D[i]=="8")  
Dlsum+=8;  
else if (D[i]=="9")  
Dlsum+=9;  
else if (D[i]=="10"||D[i]=="Jack"||D[i]=="Queen"||D[i]=="King")  
Dlsum+=10;  
else if (D[i]=="Ace")  
Dlsum+=11;  
   
if(Dlsum<=21){  
cout<<"The Dealer's total is "<<Dlsum<<endl;}  
else if(Dlsum>21 && (D[27]=="Ace"||D[28]=="Ace"||D[i]=="Ace")){  
Dlsum-=10;  
cout<<"The Dealer's total is "<<Dlsum<<endl;}  
else if (Dlsum>21){  
cout<<"The Dealer's total is "<<Dlsum<<endl;  
cout<<"The Dealer went over 21! The Dealer Busted! You Win!!!"<<endl; 
w++;}  
i++;  
 
 
}while((Dlsum<17));}   
}  
 
 
//Display Game 
void GameDis(int &S, int &D, int &l,int &w, int &p){   
    
if(D>S &&D>=17 && D<=21) {   
cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;   
cout<<"You Lose! The dealer wins!"<<endl;  
l++; 
}   
else if(D==S && D>=17){   
cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;   
cout<<"You push!"<<endl; 
p++; 
}   
else if(D<S && D>=17){   
cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;   
cout<<"Congratulations! You Win!"<<endl; 
w++;} 
 
 
}  
//Output the score of how many times win, lose, push 
void Score(int &l, int &w, int &p){ 
    int array[2][3]; 
 //Assign Player Wins 
    array[0][0]=w; 
    //Assign Player Loses 
    array[0][1]=l; 
    //Assign Player Pushes 
    array[0][2]=p; 
    //Assign Dealer Wins 
    array[1][0]=l; 
    //Assign Dealer loses 
    array[1][1]=w; 
    //Assign Dealer Push 
    array[1][2]=p; 
    cout<<"        "<<setw(6)<<"WIN"<<setw(5)<<"LOSE"<<setw(5)<<"PUSH"<<endl; 
    for(int j=0;j<2;j++){ 
        for(int i=0;i<3;i++){ 
            if(j==0){ 
                if(i==0) 
                    cout<<setw(8)<<"Player "<<setw(5)<<array[j][i]; 
                else  
                    cout<<setw(5)<<array[j][i]; 
                if(i==2) 
                    cout<<endl;} 
            else if(j==1){ 
                if(i==0) 
                    cout<<setw(8)<<"Dealer "<<setw(5)<<array[j][i]; 
                else 
                    cout<<setw(5)<<array[j][i]; 
                if(i==2) 
                    cout<<endl;} 
        } 
    } 
     
} 
//Bubble Sort  
void sort(string a[], int b){  
bool swap;  
string temp;  
do{  
    swap=false;  
    for(int i=0; i<(b-1);i++){  
       if(a[i]>a[i+1]){  
            temp=a[i];  
         a[i]=a[i+1];  
         a[i+1]=temp;  
         swap=true;  
        }  
    }  
}while(swap);  
}  