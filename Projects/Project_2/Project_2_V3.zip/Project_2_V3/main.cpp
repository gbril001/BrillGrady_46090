/*         
 * File:   main.cpp        
 * Author: Grady Brill        
 * Purpose:Project2_V3 
 * Created on July 10, 2015, 10:23 AM        
 */        
//System Libraries        
#include <iostream>//I/O Library        
#include <cstdlib>    
#include <ctime>    
#include <string>    
#include <algorithm> 
#include <vector> 
        
using namespace std; //namespace for iostream        
//User Libraries       
       
//Global Constants        
       
//Function Prototypes  
   int FstCds(vector<string> d); 
   int PlPlay(vector<string> d, int S, char C); 
   int DlPlay(vector<string> D, int S); 
   void GameDis(int S, int D); 
//Execution Begins Here!        
int main(int argc, char** argv) {      
//Declare Variables    
    char choice; 
    int Sum, DlSum; 
    vector<string> deck; 
    string base[] = {"2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace",};  
    string suit[] = {"Diamonds", "Hearts", "Spades", "Clubs"}; 
//Fill the deck 
 for(int i = 0; i <(4); ++i)  { 
      for(int j =0; j <(13); ++j)  
              deck.push_back(base[j]);}  
//Set the Random Time Seed 
srand(static_cast<unsigned int>(time(0))); 
//Shuffle the deck 
 random_shuffle(deck.begin(),deck.end()); 
// for (int i=0; i<52;i++) 
//     cout<<deck[i]<<endl; 
//Output the play 
    cout<<"Your cards are "<<deck[0]<<" and "<<deck[1]<<endl; 
        Sum=FstCds(deck); 
    cout<<"Your total is "<<Sum<<endl; 
    cout<<"The dealer is showing a "<<deck[27]<<endl; 
    cout<<"Would you like to hit or stay? Enter 'h' for hit or 's' for stay."<<endl; 
    cin>>choice; 
    Sum=PlPlay(deck,Sum, choice); 
    DlSum=DlPlay(deck,Sum); 
    GameDis(Sum,DlSum); 
    return 0;        
}      
//first two cards 
int FstCds(vector<string> d){ 
    int S=0; 
    for (int i=0; i<2;i++){ 
    if (d[i]=="2") 
            S+=2; 
        else if (d[i]=="3") 
            S+=3; 
        else if (d[i]=="4") 
            S+=4; 
        else if (d[i]=="5") 
            S+=5; 
        else if (d[i]=="6") 
            S+=6; 
        else if (d[i]=="7") 
            S+=7; 
        else if (d[i]=="8") 
            S+=8; 
        else if (d[i]=="9") 
            S+=9; 
        else if (d[i]=="10"||d[i]=="Jack"||d[i]=="Queen"||d[i]=="KIng") 
            S+=10; 
        else if (d[i]=="Ace") 
            S+=11;} 
    return S; 
} 
int PlPlay(vector<string> d, int S, char C){ 
   if (C=='h'){ 
       int i=2; 
        do{  
            cout<<"You got a "<<d[i]<<endl; 
            if (d[i]=="2") 
                S+=2; 
            else if (d[i]=="3") 
                S+=3; 
            else if (d[i]=="4") 
                S+=4; 
            else if (d[i]=="5") 
                S+=5; 
            else if (d[i]=="6") 
                S+=6; 
            else if (d[i]=="7") 
                S+=7; 
            else if (d[i]=="8") 
                S+=8; 
            else if (d[i]=="9") 
                S+=9; 
            else if (d[i]=="10"||d[i]=="Jack"||d[i]=="Queen"||d[i]=="King") 
                S+=10; 
            else if (d[i]=="Ace") 
                S+=11; 
         
        if(S<=21){ 
        cout<<"Your total is "<<S<<endl;} 
        else if(S>21 && (d[0]=="Ace"||d[1]=="Ace"||d[i]=="Ace")){ 
            S-=10; 
        cout<<"Your total is "<<S<<endl;} 
        else if (S>21){ 
            cout<<"Your total is "<<S<<endl; 
            cout<<"You went over 21! You busted!!!"<<endl;} 
        if(S<=21){ 
        cout<<"Would you like to hit or stay? Enter 'h' for hit or 's' for stay."<<endl; 
        cin>>C;} 
        i++; 
    }while((C=='h')&&(S<=21));}  
   return S; 
} 
int DlPlay(vector<string> D, int S){ 
    int Dlsum; 
    if (S<=21){ 
        int i=29; 
        do{  
            cout<<"The Dealer got a "<<D[i]<<endl; 
            if (D[i]=="2") 
                Dlsum+=2; 
            else if (D[i]=="3") 
                Dlsum+=3; 
            else if (D[i]=="4") 
                Dlsum+=4; 
            else if (D[i]=="5") 
                Dlsum+=5; 
            else if (D[i]=="6") 
                Dlsum+=6; 
            else if (D[i]=="7") 
                Dlsum+=7; 
            else if (D[i]=="8") 
                Dlsum+=8; 
            else if (D[i]=="9") 
                Dlsum+=9; 
            else if (D[i]=="10"||D[i]=="Jack"||D[i]=="Queen"||D[i]=="King") 
                Dlsum+=10; 
            else if (D[i]=="Ace") 
                Dlsum+=11; 
         
        if(Dlsum<=21){ 
        cout<<"The Dealer's total is "<<Dlsum<<endl;} 
        else if(Dlsum>21 && (D[27]=="Ace"||D[28]=="Ace"||D[i]=="Ace")){ 
            Dlsum-=10; 
        cout<<"The Dealer's total is "<<Dlsum<<endl;} 
        else if (Dlsum>21){ 
            cout<<"The Dealer's total is "<<Dlsum<<endl; 
            cout<<"The Dealer went over 21! The Dealer Busted! You Win!!!"<<endl;} 
        if(Dlsum<=21){ 
        cout<<"The Dealer must hit"<<endl;} 
        i++; 
        }while((Dlsum<17));} 
    return Dlsum; 
} 
void GameDis(int S, int D){       
if(D>S &&D>=17 && D<=21) {       
        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;       
        cout<<"You Lose! The dealer wins!"<<endl; }       
else if(D==S && D>=17){       
        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;       
        cout<<"You push!"<<endl;}        
else if(D<S && D>=17){       
        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;       
        cout<<"Congratulations! You Win!"<<endl;}}   
 