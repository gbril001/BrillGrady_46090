/*      
 * File:   main.cpp     
 * Author: Grady Brill     
 * Purpose: Project 1: BlackJack with Array V4 
 * Created on July 10, 2015, 10:23 AM     
 */     
//System Libraries     
#include <iostream>//I/O Library     
#include <cstdlib> 
#include <ctime> 
#include <string> 
     
using namespace std; //namespace for iostream     
//User Libraries    
    
//Global Constants     
    
//Function Prototypes     
int DealCd1(int a[],string  b[], int S); 
int DealCd2(int a[],string  b[]); 
char HorS(); 
void Dealer0(int a[],string b[],int S, int D, char C); 
//Player card's functions
int Player1(int a[],string b[],int S,int D, char C); 
int Player2(int a[],string b[],int S,int D, char C); 
int Player3(int a[],string b[],int S,int D, char C); 
int Player4(int a[],string b[],int S,int D, char C); 
int Player5(int a[],string b[],int S,int D, char C); 
//Dealer card's Functions
int Dealer1(int a[],string b[],int S,int D, char C); 
int Dealer2(int a[],string b[],int S,int D, char C); 
int Dealer3(int a[],string b[],int S,int D, char C); 
int Dealer4(int a[],string b[],int S,int D, char C); 
int Dealer5(int a[],string b[],int S,int D, char C); 
int Dealer6(int a[],string b[],int S,int D, char C); 
int Dealer7(int a[],string b[],int S,int D, char C); 
int Dealer8(int a[],string b[],int S,int D, char C); 
int Dealer9(int a[],string b[],int S,int D, char C); 
int Dealer10(int a[],string b[],int S,int D, char C); 
int Dealer11(int a[],string b[],int S,int D, char C); 
int Dealer12(int a[],string b[],int S,int D, char C); 
int Dealer13(int a[],string b[],int S,int D, char C); 
int Dealer14(int a[],string b[],int S,int D, char C); 
int Dealer15(int a[],string b[],int S,int D, char C); 
int Dealer16(int a[],string b[],int S,int D, char C); 
int Dealer17(int a[],string b[],int S,int D, char C); 
int Dealer18(int a[],string b[],int S,int D, char C); 
int Dealer19(int a[],string b[],int S,int D, char C); 
int Dealer20(int a[],string b[],int S,int D, char C); 
int Dealer21(int a[],string b[],int S,int D, char C); 
int Dealer22(int a[],string b[],int S,int D, char C); 
int Dealer23(int a[],string b[],int S,int D, char C); 
int Dealer24(int a[],string b[],int S,int D, char C); 
int Dealer25(int a[],string b[],int S,int D, char C); 
void DisGame(int Sum); //Not used
 
//Execution Begins Here!     
int main(int argc, char** argv) {   
//    //set random seed 
//    srand(static_cast<unsigned int>(time(0))); 
//Declare Variables     
    char choice; 
    const unsigned int SIZE=14; 
    unsigned int rCard[SIZE]={1,2,3,4,5,6,7,8,9,10,11,12,13,14}; //Set list of cards from 1 to 14 (for 1 to ace) numerical value
    unsigned int rCardP[SIZE]={1,2,3,4,5,6,7,8,9,10,10,10,10,11}; //Set card's actual value, ex ace=11.
    string rCardS[SIZE]={"1", "2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace"}; //String value of cards for output
    int RandAry[SIZE]; //Math array with random cards numerical value for adding sums
    string RanAryS[SIZE];//Displayed array with random cards string value for output 
    bool doAgain=true; //play again loop bool value
    int DlSum; 
//Output     
//Randomly fills the array 
    do{ //Do you want to play again do-while loop
         
        //set random seed 
        srand(static_cast<unsigned int>(time(0))); //set random seed inside of loop so each loop has random numbers
        //Declare loop variable 
         int Sum=0; //The sum of the player's cards, initialize to 0 for each loop
         
     //Randomly assigns numbers to RandAry. 
    for(int i=0; i<14; i++){ 
       RandAry[i]=(rand()%14+1); 
       //RandAry[0] = 5 
       // rCard[4] 
   } 
   int pos;//position in array 
   //Sets the rcard array equal to the random array 
   for(int i=0; i<14; i++){ 
       for(int j=0; j<14; j++){ 
            if (rCard[j]==RandAry[i]){ //Sets the rcard array equal to the random array,
                                       //allows the program to sync the numerical values position and 
                                       //string values position in the two seperate arrays
                pos=j;break; 
            } 
            
       } 
       RanAryS[i]=rCardS[pos];//Sets the rcard string array equal to the RanAryS string array
        
   } 
    
//Testing function for arrays randomization and aligning; Shows the output of each array 
//   for (int i=0; i<14; i++){ 
//       cout<<RandAry[i]<<" "<<RanAryS[i]<<endl; 
//   }
   
// Given the string value it assigns that position the actual card value (ex Ace=11 now instead of 14)
   for (int i=0; i<14; i++){ 
       if (RanAryS[i]=="1"){ 
            RandAry[i]=1; 
        } 
       else if (RanAryS[i]=="2"){ 
            RandAry[i]=2; 
        } 
       else if (RanAryS[i]=="3"){ 
            RandAry[i]=3; 
        } 
       else if (RanAryS[i]=="4"){ 
            RandAry[i]=4; 
        } 
       else if (RanAryS[i]=="5"){ 
            RandAry[i]=5; 
        } 
       else if (RanAryS[i]=="6"){ 
            RandAry[i]=6; 
        } 
        else if (RanAryS[i]=="7"){ 
            RandAry[i]=7; 
        } 
       else if (RanAryS[i]=="8"){ 
            RandAry[i]=8; 
        } 
       else if (RanAryS[i]=="9"){ 
            RandAry[i]=9; 
        } 
        else if (RanAryS[i]=="10"||RanAryS[i]=="Jack" || RanAryS[i]=="Queen" || RanAryS[i]=="King"){ 
            RandAry[i]=10; 
                } 
        else if (RanAryS[i]=="Ace"){ 
            RandAry[i]=11; 
                } 
   }//end of for function for assigning integer values for string array 
   
   //Call all functions 
    
   Sum=DealCd1(RandAry, RanAryS, Sum); 
   if (Sum!=21){ 
   DlSum=DealCd2(RandAry, RanAryS); 
   if (DlSum!=21){ 
   choice=HorS(); 
   Dealer0(RandAry, RanAryS, Sum, DlSum, choice); 
    if (choice=='s'){ 
        DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice); 
        if(DlSum<17) 
            DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);   
            if(DlSum<17) 
                 DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);  
                    if(DlSum<17) 
                        DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);  
                            if(DlSum<17) 
                                DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);  
        }//choice 1 stay 
    
    else if (choice=='h'){//choice1 hit 
        Sum=Player1(RandAry,RanAryS,Sum, DlSum ,choice); 
        if(Sum<=21){ 
            choice=HorS();//choice 2 
            if(choice=='s'){//choice 2 stay 
                //input dealer stay after second stay 
              DlSum=Dealer6(RandAry, RanAryS,Sum,DlSum, choice); 
                if(DlSum<17) 
                    DlSum=Dealer7(RandAry, RanAryS,Sum,DlSum, choice);   
                    if(DlSum<17) 
                         DlSum=Dealer8(RandAry, RanAryS,Sum,DlSum, choice);  
                            if(DlSum<17) 
                                DlSum=Dealer9(RandAry, RanAryS,Sum,DlSum, choice);  
                                    if(DlSum<17) 
                                        DlSum=Dealer10(RandAry, RanAryS,Sum,DlSum, choice); 
                            }//choice 2 stay 
             
            else if(choice=='h'){//choice 2 hit 
                Sum=Player2(RandAry,RanAryS,Sum, DlSum ,choice); 
                    if(Sum<=21){ 
                        choice=HorS();//choice 3 stay 
                        cout<<choice<<endl; 
                       if(choice=='s'){//choice 3 stay 
                       //input dealer play after 3rd stay 
                       DlSum=Dealer11(RandAry, RanAryS,Sum,DlSum, choice); 
                        if(DlSum<17) 
                            DlSum=Dealer12(RandAry, RanAryS,Sum,DlSum, choice);   
                             if(DlSum<17) 
                                 DlSum=Dealer13(RandAry, RanAryS,Sum,DlSum, choice);  
                                    if(DlSum<17) 
                                        DlSum=Dealer14(RandAry, RanAryS,Sum,DlSum, choice);  
                                            if(DlSum<17) 
                                                DlSum=Dealer15(RandAry, RanAryS,Sum,DlSum, choice); 
                                                    }//choice 3 stay 
                         
            else if(choice=='h'){//choice 3 hit 
                Sum=Player3(RandAry,RanAryS,Sum, DlSum ,choice); 
                    if(Sum<=21){  
                        choice=HorS();//choice 4 
                        cout<<choice<<endl; 
                         if(choice=='s'){//choice 4 stay 
                        //input dealer play after 4th stay 
                          DlSum=Dealer16(RandAry, RanAryS,Sum,DlSum, choice); 
                            if(DlSum<17) 
                                DlSum=Dealer17(RandAry, RanAryS,Sum,DlSum, choice);   
                                    if(DlSum<17) 
                                        DlSum=Dealer18(RandAry, RanAryS,Sum,DlSum, choice);  
                                            if(DlSum<17) 
                                                DlSum=Dealer19(RandAry, RanAryS,Sum,DlSum, choice);  
                                                    if(DlSum<17) 
                                                        DlSum=Dealer20(RandAry, RanAryS,Sum,DlSum, choice); 
                                                                }//choice 4 stay 
                                         
            else if(choice=='h'){//choice 4 hit 
                Sum=Player4(RandAry,RanAryS,Sum, DlSum ,choice); 
                    if(Sum<=21){  
                        choice=HorS();//choice 5 
                if(choice=='s'){//choice 5 stay 
                //input dealer play after 5th stay 
                    DlSum=Dealer21(RandAry, RanAryS,Sum,DlSum, choice); 
                        if(DlSum<17) 
                             DlSum=Dealer22(RandAry, RanAryS,Sum,DlSum, choice);   
                                 if(DlSum<17) 
                                     DlSum=Dealer23(RandAry, RanAryS,Sum,DlSum, choice);  
                                        if(DlSum<17) 
                                            DlSum=Dealer24(RandAry, RanAryS,Sum,DlSum, choice);  
                                                if(DlSum<17) 
                                                     DlSum=Dealer25(RandAry, RanAryS,Sum,DlSum, choice); 
                                                        }//choice 5 stay 
                                         
            else if(choice=='h'){//choice 5 hit 
                Sum=Player5(RandAry,RanAryS,Sum, DlSum ,choice); 
                                 
                         }//choice 5 hit                 
                      }//fourth if sum>=21 for choice 5 function 
                    }//choice 4 hit                      
                 }//third if sum>=21 for choice 4 function       
              }//choice 3 hit 
           }// second if sum>=21 for choice 3 function  
        }//choice 2 hit 
      }// first if sum>=21 for choice 2 function  
    }//choice 1 hit 
   }//if DlSum !=21 before choice 1 
   }//DealCd2 if sum!=21 
    
    cout<<endl; 
    char response;  
    do{
   cout<<"Would you like to play again? Enter y for yes or n for no.\n";
    cin>>response; 
                 //Prevent other characters from being entered aka fail safe
                if (response=='y'||response=='n')
                {doAgain=false;}
                 else{
                doAgain=true;
                 }
                 }while(doAgain);
            
    if (response=='y')doAgain=true;     
    else doAgain=false;     
        }while(doAgain); 
    return 0;     
}   
 
 /*****************************************************************************
  *                             DealCd1                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum                                            *
  *   Purpose: Show the players cards and their total value                   *
  *             Check for blackjack                                           *
  *///*************************************************************************
int DealCd1(int a[],string b[], int S){ 
    cout<<endl;    
cout<<"Your cards are "<<b[0]<<" & "<<b[2]<<"."<<endl;//Player's Hand   
S=S+a[0]+a[2];     
if (S==21){    
    cout<<"You got BlackJack! You win!"<<endl;      
       }    
else if (S>21){   
    cout<<"rcard1a: "<<b[0]<<" rcard3a: "<<b[2]<<endl;   
        }   
cout<<"Your total is "<<S<<"."<<endl;  
return S; 
} 
 
 /*****************************************************************************
  *                             DealCd2                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum                                            *
  *   Purpose: Show the dealer's card and check for blackjack                 *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
//D is the dealer Sum 
int DealCd2(int a[], string b[]){ 
    int D; 
cout<<"The Dealer is showing a "<<b[3]<<endl;    
D=a[1]+a[3]; 
if (((a[1]==11) || (a[3]==11)) && (D>21)){ 
         D=D-10; 
                }  
if((a[3]==10) || (a[3]==11)){ 
        cout<<"The Dealer checks their cards for a BlackJack"<<endl; 
        if (D==21){   
                cout<<"Uh-Oh! The Dealer's other card was a "<<b[1]<<endl;   
                cout<<"The Dealer got a BlackJack! You lose!"<<endl; }   
        else if(D!=21) cout<<"The Dealer doesn't have a BlackJack."<<endl; } 
    return D; 
    } 
//The hit or stay question that returns the choice 
/******************************************************************************
  *                   Choice Function HorS (Hit or Stay)                      *
  *****************************************************************************
  *   Purpose: If Sum<=21 ask the user whether they want to hit or stay       *
  *   Return: Choice                                                          *
  *///************************************************************************* 
char HorS(){ 
    bool doAgain=true;
    char choice;
    do{
    cout<<"Would you like to stay or hit? Enter 's' for stay or 'h' for hit."<<endl;       
    cin>>choice; 
        if (choice=='s'||choice=='h')
        {doAgain=false;}
        else{
            doAgain=true;
        }
    }while(doAgain);
        return choice;
        } 
 /*****************************************************************************
  *                             Dealer0                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: Nothing                                                         *
  *///************************************************************************* 
void Dealer0(int a[],string b[],int S,int D, char C){ 
    if(C=='s'){//If you choose to stay the dealers hand is now played out     
                 //Choice1 Stay appears good   
        cout<<"The dealer has a "<<b[1]<<" & "<<b[3]<<endl;     
            D= a[1]+a[3]; 
         cout<<"The Dealer's total is "<<D<<endl;        
                if(D>=17 & D<21) {     
                        cout<<"The dealer stays"<<endl;     
                if(D>S &&D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The dealer wins!"<<endl; }    
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;}}     
                } 
} 
 
 /*****************************************************************************
  *                             Dealer1                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer1(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit      
                  cout<<"The Dealer must hit. The Dealer got a "<<b[4]<<endl;   
                        D=a[1]+a[3]+a[4];   
                if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[4]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;    
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer2                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer2(int a[],string b[],int S,int D, char C){ 
         if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[5]<<endl;   
                        D=a[1]+a[3]+a[4]+a[5];     
                if (D<=21){ 
                        cout<<"The dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[4]==11)||(a[5]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer3                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer3(int a[],string b[],int S,int D, char C){ 
         if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[6]<<endl;   
                        D=a[1]+a[3]+a[4]+a[5]+a[6];     
                        if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[4]==11)||(a[5]==11)||(a[6]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){ 
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer4                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer4(int a[],string b[],int S,int D, char C){ 
         if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[7]<<endl;   
                        D=a[1]+a[3]+a[4]+a[5]+a[6]+a[7];     
                       if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[4]==11)||(a[5]==11)||(a[6]==11)||(a[7]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer5                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer5(int a[],string b[],int S,int D, char C){ 
         if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[8]<<endl;   
                        D=a[1]+a[3]+a[4]+a[5]+a[6]+a[7]+a[8];     
                       if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[4]==11)||(a[5]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }     
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
//First card given to player if hit
/******************************************************************************
  *                             Player1                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Show the results of the player choosing to hit                 *
  *             Out put the user's new sum, if over 21 show bust, if over 21  *
  *            with ace subtract 10 from the sum and show new sum             *
  *   Return: Sum                                                             *
  *///************************************************************************* 
int Player1(int a[],string b[],int S,int D, char C){ 
    cout<<"You got a "<<b[4]<<endl;//if bust statement     
            S= a[0]+a[2]+a[4];  
            if(S<=21){ 
            cout<<"Your new sum is "<<S<<endl; } 
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)) && (S>21)){ 
//                cout<<a[0]<<" "<<a[2]<<" "<<a[4]<<endl; 
                S=S-10; 
                cout<<"Your new total is "<<S<<endl; 
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl; 
                        } 
                        }    
            else if(S>21){    
                    cout<<"Your new total is "<<S<<endl; 
                    cout<<"Sorry you went over 21, you busted!"<<endl;}  
            return S; 
} 
//Dealer6 to Dealer10 are used after Player1h 
/*****************************************************************************
  *                             Dealer6                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer6(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                        cout<<"The Dealer has a "<<b[1]<<" & "<<b[3]<<endl; 
                        cout<<"The Dealer's total is "<<D<<endl;   
                        cout<<"The Dealer must hit. The Dealer got a "<<b[5]<<endl;   
                        D=a[1]+a[3]+a[5];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[5]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }     
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer7                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer7(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[6]<<endl;   
                        D=a[1]+a[3]+a[5]+a[6];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[5]==11)||(a[6]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){ 
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer8                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer8(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[7]<<endl;   
                        D=a[1]+a[3]+a[5]+a[6]+a[7];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[5]==11)||(a[6]==11)||(a[7]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){ 
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/*****************************************************************************
  *                             Dealer9                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer9(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[8]<<endl;   
                        D=a[1]+a[3]+a[5]+a[6]+a[7]+a[8];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11)||(a[5]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        } 
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){ 
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer10                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer10(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;   
                        D=a[1]+a[3]+a[5]+a[6]+a[7]+a[8]+a[9];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[5]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 

//Second card given to player if hit 
/******************************************************************************
  *                             Player2                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Show the results of the player choosing to hit                 *
  *             Out put the user's new sum, if over 21 show bust, if over 21  *
  *            with ace subtract 10 from the sum and show new sum             *
  *   Return: Sum                                                             *
  *///************************************************************************* 
int Player2(int a[],string b[],int S,int D, char C){ 
    cout<<"You got a "<<b[5]<<endl;//if bust statement     
            S= a[0]+a[2]+a[4]+a[5];  
            if(S<=21){ 
            cout<<"Your new sum is "<<S<<endl; } 
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)||(a[5]==11)) && (S>21)){ 
//                 cout<<a[0]<<" "<<a[2]<<" "<<a[4]<<" "<<a[5]<<endl; 
                S=S-10; 
                cout<<"Your new total is "<<S<<endl; 
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl; 
                        } 
                        }    
            else if(S>21){     
                    cout<<"Your new total is "<<S<<endl; 
                    cout<<"Sorry you went over 21, you busted!"<<endl;}  
            return S; 
} 
//Dealer11 to Dealer15 are used after Player2 
/******************************************************************************
  *                             Dealer11                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer11(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                        cout<<"The Dealer has a "<<b[1]<<" & "<<b[3]<<endl; 
                        cout<<"The Dealer's total is "<<D<<endl;   
                        cout<<"The Dealer must hit. The Dealer got a "<<b[6]<<endl;   
                        D=a[1]+a[3]+a[6];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[6]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer12                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer12(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[7]<<endl;   
                        D=a[1]+a[3]+a[6]+a[7];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11)||(a[6]==11)||(a[7]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        } 
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer13                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer13(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[8]<<endl;   
                        D=a[1]+a[3]+a[6]+a[7]+a[8];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer15                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer14(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;   
                        D=a[1]+a[3]+a[6]+a[7]+a[8]+a[9];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){ 
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){  
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer15                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer15(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[10]<<endl;   
                        D=a[1]+a[3]+a[6]+a[7]+a[8]+a[9]+a[10];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        } 
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 

//third card given to player if hit 
/******************************************************************************
  *                             Player3                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Show the results of the player choosing to hit                 *
  *             Out put the user's new sum, if over 21 show bust, if over 21  *
  *            with ace subtract 10 from the sum and show new sum             *
  *   Return: Sum                                                             *
  *///************************************************************************* 
int Player3(int a[],string b[],int S,int D, char C){ 
    cout<<"You got a "<<b[6]<<endl;//if bust statement     
            S= a[0]+a[2]+a[4]+a[5]+a[6];  
            if(S<=21){ 
            cout<<"Your new sum is "<<S<<endl; } 
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)) && (S>21)){ 
//                cout<<a[0]<<" "<<a[2]<<" "<<a[4]<<" "<<a[5]<<" "<<a[6]<<endl; 
                S=S-10; 
                cout<<"Your new total is "<<S<<endl; 
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl; 
                        }   } 
            else if(S>21){   
                    cout<<"Your new total is "<<S<<endl; 
                    cout<<"Sorry you went over 21, you busted!"<<endl;}  
            return S; 
} 
//Dealer16 to Dealer20 are used after Player3 
/******************************************************************************
  *                             Dealer16                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer16(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                        cout<<"The Dealer has a "<<b[1]<<" & "<<b[3]<<endl; 
                        cout<<"The Dealer's total is "<<D<<endl;   
                        cout<<"The Dealer must hit. The Dealer got a "<<b[7]<<endl;   
                        D=a[1]+a[3]+a[7];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) ||(a[7]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){  
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer17                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer17(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[8]<<endl;   
                        D=a[1]+a[3]+a[7]+a[8];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) ||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }  
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer18                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer18(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;   
                        D=a[1]+a[3]+a[7]+a[8]+a[9];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer19                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer19(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[10]<<endl;   
                        D=a[1]+a[3]+a[7]+a[8]+a[9]+a[10];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }     
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer20                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer20(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[11]<<endl;   
                        D=a[1]+a[3]+a[7]+a[8]+a[9]+a[10]+a[11];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[11]==11)||(a[7]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){  
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 

//fourth card given to player if hit 
/******************************************************************************
  *                             Player4                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Show the results of the player choosing to hit                 *
  *             Out put the user's new sum, if over 21 show bust, if over 21  *
  *            with ace subtract 10 from the sum and show new sum             *
  *   Return: Sum                                                             *
  *///************************************************************************* 
int Player4(int a[],string b[],int S,int D, char C){ 
    cout<<"You got a "<<b[7]<<endl;//if bust statement     
            S= a[0]+a[2]+a[4]+a[5]+a[6]+a[7];  
            if(S<=21){ 
            cout<<"Your new sum is "<<S<<endl; } 
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)||(a[7]==11)) && (S>21)){ 
//                cout<<a[0]<<" "<<a[2]<<" "<<a[4]<<" "<<a[5]<<" "<<a[6]<<" "<<a[7]<<endl; 
                S=S-10; 
                cout<<"Your new total is "<<S<<endl; 
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl; 
                        } 
                        }    
            else if(S>21){     
                    cout<<"Your new total is "<<S<<endl; 
                    cout<<"Sorry you went over 21, you busted!"<<endl;}  
            return S; 
} 
//Dealer21 to Dealer25 are used after Player4 
/******************************************************************************
  *                             Dealer21                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer21(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                        cout<<"The Dealer has a "<<b[1]<<" & "<<b[3]<<endl; 
                        cout<<"The Dealer's total is "<<D<<endl;   
                        cout<<"The Dealer must hit. The Dealer got a "<<b[8]<<endl;   
                        D=a[1]+a[3]+a[8];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) ||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer22                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer22(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;   
                        D=a[1]+a[3]+a[8]+a[9];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }     
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer23                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer23(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[10]<<endl;   
                        D=a[1]+a[3]+a[8]+a[9]+a[10];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[8]==11)||(a[9]==11)||(a[10]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){   
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer24                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer24(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[11]<<endl;   
                        D=a[1]+a[3]+a[8]+a[9]+a[10]+a[11];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[11]==11)||(a[10]==11)||(a[9]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }     
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){ 
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){    
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 
/******************************************************************************
  *                             Dealer25                                      *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Run through the dealer's options stay or hit                   *
  *            Determine who won if DlSum>=17, show win, push, and lose       *
  *   Return: DlSum                                                           *
  *///************************************************************************* 
int Dealer25(int a[],string b[],int S,int D, char C){ 
     if(D<17){//If the dealer does not have 17 it must hit   
                    // 
                        cout<<"The Dealer must hit. The Dealer got a "<<b[12]<<endl;   
                        D=a[1]+a[3]+a[8]+a[9]+a[10]+a[11]+a[12];     
                         if (D<=21){ 
                        cout<<"The Dealer's total is "<<D<<endl;} 
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[11]==11)||(a[12]==11)||(a[8]==11)) && (D>21)){ 
                    D=D-10; 
                    cout<<"The Dealer's new total is "<<D<<endl; 
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl; 
                        } 
                        }      
                else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;} 
                if(D>21)    
                    cout<<"The Dealer busted! You Win!"<<endl;    
                if(D>=17 & D<21)     
                        cout<<"The dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {    
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;    
                        cout<<"You Lose! The Dealer wins!"<<endl; }     
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;    
                        cout<<"You push!"<<endl;}     
                else if(D<S && D>=17){  
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;    
                        cout<<"Congratulations! You Win!"<<endl;} 
                        return D; 
            } 
} 

//Fifth Card given to player if choice is hit 
/******************************************************************************
  *                             Player1                                       *
  *****************************************************************************
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             *
  *   Purpose: Show the results of the player choosing to hit                 *
  *             Out put the user's new sum, if over 21 show bust, if over 21  *
  *            with ace subtract 10 from the sum and show new sum             *
  *            If this sum is less than 21 player automatically wins due to   *
  *             Hitting 5 times, having seven cards and still not busting     *
  *             This playground rule was stipulated to shorten repeating code *
  *             And Game                                                      *
  *   Return: Sum                                                             *
  *///************************************************************************* 
int Player5(int a[],string b[],int S,int D, char C){ 
    cout<<"You got a "<<b[8]<<endl;//if bust statement     
            S= a[0]+a[2]+a[4]+a[5]+a[6]+a[7]+a[8];  
            if(S<=21){ 
            cout<<"Your new sum is "<<S<<endl; } 
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (S>21)){ 
//                cout<<a[0]<<" "<<a[2]<<" "<<a[4]<<" "<<a[5]<<" "<<a[6]<<" "<<a[7]<<" "<<a[8]<<endl; 
                S=S-10; 
                cout<<"Your new total is "<<S<<endl; 
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl; 
                        } 
                        }    
             
            else if(S>21){   
                    cout<<"Your new total is "<<S<<endl; 
                    cout<<"Sorry you went over 21, you busted!"<<endl;}  
            if(S<21){   
                cout<<"You were able to hit 5 times, get 6 cards, and not go over 21!"<<endl;   
                cout<<"You win by default!"<<endl;}   
            return S; 
} 