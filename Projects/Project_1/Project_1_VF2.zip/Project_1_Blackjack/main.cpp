/*       
 * File:   main.cpp      
 * Author: Grady Brill      
 * Purpose: Project 1 Blackjack 
 * Created on July 21, 2015, 12:23 PM      
 */      
//System Libraries      
#include <iostream>//I/O Library      
#include <cstdlib>  
#include <ctime>  
#include <string>  
#include <fstream>
      
using namespace std; //namespace for iostream      
//User Libraries     
     
//Global Constants      
     
//Function Prototypes
void GameDis(int RandAry[],string RanAryS[],int Sum,int DlSum, char choice);
int DealCd1(int a[],string  b[], int S);  
int DealCd2(int a[],string  b[]);  
char HorS();  
//Player card's functions 
int Player1(int a[],string b[],int S,int D, char C);  
int Player2(int a[],string b[],int S,int D, char C);  
int Player3(int a[],string b[],int S,int D, char C);  
int Player4(int a[],string b[],int S,int D, char C);  
int Player5(int a[],string b[],int S,int D, char C);  
//Dealer card's Functions 
int Dealer0(int a[],string b[],int S, int D, char C);  
int Dealer1(int a[],string b[],int S,int D, char C);  
int Dealer2(int a[],string b[],int S,int D, char C);  
int Dealer3(int a[],string b[],int S,int D, char C);  
int Dealer4(int a[],string b[],int S,int D, char C);  
int Dealer5(int a[],string b[],int S,int D, char C);  
//Execution Begins Here!      
int main(int argc, char** argv) {    
//Declare Variables      
    const unsigned int SIZE=14;  
    unsigned int rCard[SIZE]={1,2,3,4,5,6,7,8,9,10,11,12,13,14}; //Set list of cards from 1 to 14 (for 1 to ace) numerical value 
    string rCardS[SIZE]={"1", "2","3","4","5","6","7","8","9","10","Jack","Queen","King","Ace"}; //String value of cards for output 
    int RAndAry[SIZE]; //Math array with random cards numerical value for adding sums 
    string RAnAryS[SIZE];//Displayed array with random cards string value for output  
    bool doAgain=true; //play again loop bool value  
    char Choice; 
    
//Output       
    do{ //Do you want to play again do-while loop 
//Declare Loop Variables
int SUM=0; //The sum of the player's cards, initialize to 0 for each loop  
int DLSum=0;//Dealer's Total Hand Sum
int pos;//position in array

//set random seed inside the loop
srand(static_cast<unsigned int>(time(0))); 
          
//Randomly assigns numbers to RAndAry.  
        for(int i=0; i<14; i++){  
                RAndAry[i]=(rand()%14+1);  
              }  
 
//Sets the rcard array equal to the random array  
   for(int i=0; i<14; i++){  
       for(int j=0; j<14; j++){  
            if (rCard[j]==RAndAry[i]){ //Sets the rcard array equal to the random array, 
                                       //allows the program to sync the numerical values position and  
                                       //string values position in the two seperate arrays 
                pos=j;break;  
            }        
       }  
       RAnAryS[i]=rCardS[pos];//Sets the rcard string array equal to the RanAryS string array 
   } 

// Given the string value it assigns that position the actual card value (ex Ace=11 now instead of 14)  
   for (int i=0; i<14; i++){   
        if (RAnAryS[i]=="10"||RAnAryS[i]=="Jack" || RAnAryS[i]=="Queen" || RAnAryS[i]=="King"){   
            RAndAry[i]=10;  }   
        else if (RAnAryS[i]=="Ace"){   
            RAndAry[i]=11;  }   
                }//end of for function for assigning integer values for string array  

//Call Game
GameDis( RAndAry, RAnAryS, SUM, DLSum, Choice);

//End the do while by asking if they want to play again
    cout<<endl;  
    char response;   
    do{ 
   cout<<"Would you like to play again? Enter y for yes or n for no.\n"; 
    cin>>response;  
                 //Prevent other characters from being entered aka fail safe 
                if (response=='y'||response=='n') 
                {doAgain=false;} 
                 else{ 
                doAgain=true; 
                 } 
                 }while(doAgain); 
             
    if (response=='y')doAgain=true;      
    else doAgain=false;      
        }while(doAgain);  
 //Read in file concept
 //After finished playing outputs "Thanks For Playing!!!"
        ifstream input;
        string thanks;
         input.open("BJfile.txt");
         while(!input.eof()){
                input>>thanks;
                 cout<<thanks<<" ";}
    return 0;      
}    

//FUNCTIONS FOR GAME

 /***************************************************************************** 
  *                             DealCd1                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum                                            * 
  *   Purpose: Show the players cards and their total value                   * 
  *             Check for blackjack                                           * 
  *///************************************************************************* 
int DealCd1(int a[],string b[], int S){  
    cout<<endl; 
int D;    
cout<<"Your cards are "<<b[0]<<" & "<<b[2]<<"."<<endl;//Player's Hand    
S=a[0]+a[2];      
D=a[1]+a[3];
if (S==21){     
    cout<<"You got BlackJack!"<<endl;  
    cout<<"The Dealer checks their cards for BlackJack."<<endl;
    if (D==21)
        cout<<"The Dealer had a BlackJack too! You push!"<<endl;
    else{ cout<<"The Dealer doesn't have a BlackJack! You Win!"<<endl;}
       }     
else if (S>21){    
    cout<<"rcard1a: "<<b[0]<<" rcard3a: "<<b[2]<<endl;    
        } 
if (S<21)
cout<<"Your total is "<<S<<"."<<endl;   
return S;  
}  
  
 /***************************************************************************** 
  *                             DealCd2                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum                                            * 
  *   Purpose: Show the dealer's card and check for blackjack                 * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
//D is the dealer Sum  
int DealCd2(int a[], string b[]){  
    int D;  
cout<<"The Dealer is showing a "<<b[3]<<endl;     
D=a[1]+a[3];  
if (((a[1]==11) || (a[3]==11)) && (D>21)){  
         D=D-10;  
                }   
if((a[3]==10) || (a[3]==11)){  
        cout<<"The Dealer checks their cards for a BlackJack"<<endl;  
        if (D==21){    
                cout<<"Uh-Oh! The Dealer's other card was a "<<b[1]<<endl;    
                cout<<"The Dealer got a BlackJack! You lose!"<<endl; }    
        else if(D!=21) cout<<"The Dealer doesn't have a BlackJack."<<endl; }  
    return D;  
    }  
//The hit or stay question that returns the choice  
/****************************************************************************** 
  *                   Choice Function HorS (Hit or Stay)                      * 
  ***************************************************************************** 
  *   Purpose: If Sum<=21 ask the user whether they want to hit or stay       * 
  *   Return: Choice                                                          * 
  *///*************************************************************************  
char HorS(){  
    bool doAgain=true; 
    char choice; 
    do{ 
    cout<<"Would you like to stay or hit? Enter 's' for stay or 'h' for hit."<<endl;        
    cin>>choice;  
        if (choice=='s'||choice=='h') 
        {doAgain=false;} 
        else{ 
            doAgain=true; 
        } 
    }while(doAgain); 
        return choice; 
        }  
 /***************************************************************************** 
  *                             Dealer0                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: Nothing                                                         * 
  *///*************************************************************************  
int Dealer0(int a[],string b[],int S,int D, char C){  
    if(C=='s'){//If you choose to stay the dealers hand is now played out      
                 //Choice1 Stay appears good    
        cout<<"The dealer has a "<<b[1]<<" & "<<b[3]<<endl;      
            D= a[1]+a[3];  
         cout<<"The Dealer's total is "<<D<<endl;         
                if(D>=17 & D<21) {      
                        cout<<"The dealer stays"<<endl;      
                if(D>S &&D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The dealer wins!"<<endl; }     
                else if(D==S && D>=17){     
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}}      
                }  
    return D;
}  
 /***************************************************************************** 
  *                             Dealer1                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
int Dealer1(int a[],string b[],int S,int D, char C){  
     if(D<17){//If the dealer does not have 17 it must hit       
                  cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;    
                        D=a[1]+a[3]+a[9];    
                if (D<=21){  
                        cout<<"The Dealer's total is "<<D<<endl;}  
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)) && (D>21)){  
                    D=D-10;  
                    cout<<"The Dealer's new total is "<<D<<endl;  
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl;  
                        }  
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;}  
                if(D>21)     
                    cout<<"The Dealer busted! You Win!"<<endl;     
                if(D>=17 & D<21)      
                        cout<<"The Dealer stays"<<endl;     
                if(D>S && D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The Dealer wins!"<<endl; }      
                else if(D==S && D>=17){    
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}  
                        return D;  
            }  
}
/***************************************************************************** 
  *                             Dealer2                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
int Dealer2(int a[],string b[],int S,int D, char C){  
         if(D<17){//If the dealer does not have 17 it must hit    
                    //  
                        cout<<"The Dealer must hit. The Dealer got a "<<b[10]<<endl;    
                        D=a[1]+a[3]+a[9]+a[10];      
                if (D<=21){  
                        cout<<"The dealer's total is "<<D<<endl;}  
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)) && (D>21)){  
                    D=D-10;  
                    cout<<"The Dealer's new total is "<<D<<endl;  
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl;  
                        }  
                        }   
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;}  
                if(D>21)     
                    cout<<"The Dealer busted! You Win!"<<endl;     
                if(D>=17 & D<21)      
                        cout<<"The Dealer stays"<<endl;      
                if(D>S && D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The Dealer wins!"<<endl; }      
                else if(D==S && D>=17){     
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}  
                        return D;  
            }  
}  
/***************************************************************************** 
  *                             Dealer3                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
int Dealer3(int a[],string b[],int S,int D, char C){  
         if(D<17){//If the dealer does not have 17 it must hit    
                    //  
                        cout<<"The Dealer must hit. The Dealer got a "<<b[9]<<endl;    
                        D=a[1]+a[3]+a[9]+a[10]+a[11];      
                        if (D<=21){  
                        cout<<"The Dealer's total is "<<D<<endl;}  
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[11]==11)) && (D>21)){  
                    D=D-10;  
                    cout<<"The Dealer's new total is "<<D<<endl;  
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl;  
                        }  
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;}  
                if(D>21)     
                    cout<<"The Dealer busted! You Win!"<<endl;     
                if(D>=17 & D<21)      
                        cout<<"The Dealer stays"<<endl;      
                if(D>S && D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The Dealer wins!"<<endl; }      
                else if(D==S && D>=17){  
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}  
                        return D;  
            }  
}  
/***************************************************************************** 
  *                             Dealer4                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
int Dealer4(int a[],string b[],int S,int D, char C){  
         if(D<17){//If the dealer does not have 17 it must hit    
                    //  
                        cout<<"The Dealer must hit. The Dealer got a "<<b[12]<<endl;    
                        D=a[1]+a[3]+a[9]+a[10]+a[11]+a[12];      
                       if (D<=21){  
                        cout<<"The Dealer's total is "<<D<<endl;}  
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[11]==11)||(a[12]==11)) && (D>21)){  
                    D=D-10;  
                    cout<<"The Dealer's new total is "<<D<<endl;  
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl;  
                        }  
                        }    
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;}  
                if(D>21)     
                    cout<<"The Dealer busted! You Win!"<<endl;     
                if(D>=17 & D<21)      
                        cout<<"The Dealer stays"<<endl;      
                if(D>S && D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The Dealer wins!"<<endl; }      
                else if(D==S && D>=17){   
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}  
                        return D;  
            }  
}  
/***************************************************************************** 
  *                             Dealer5                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Run through the dealer's options stay or hit                   * 
  *            Determine who won if DlSum>=17, show win, push, and lose       * 
  *   Return: DlSum                                                           * 
  *///*************************************************************************  
int Dealer5(int a[],string b[],int S,int D, char C){  
         if(D<17){//If the dealer does not have 17 it must hit    
                    //  
                        cout<<"The Dealer must hit. The Dealer got a "<<b[13]<<endl;    
                        D=a[1]+a[3]+a[9]+a[10]+a[11]+a[12]+a[13];      
                       if (D<=21){  
                        cout<<"The Dealer's total is "<<D<<endl;}  
                else if (((a[1]==11) || (a[3]==11) || (a[9]==11)||(a[10]==11)||(a[11]==11)||(a[12]==11)||(a[13]==11)) && (D>21)){  
                    D=D-10;  
                    cout<<"The Dealer's new total is "<<D<<endl;  
                    if(D>21){cout<<"The Dealer busted! You Win!"<<endl;  
                        }  
                        }      
                        else if (D>21){cout<<"The Dealer's new total is "<<D<<endl;}  
                if(D>21)     
                    cout<<"The Dealer busted! You Win!"<<endl;     
                if(D>=17 & D<21)      
                        cout<<"The dealer stays"<<endl;      
                if(D>S && D>=17 && D<=21) {     
                        cout<<"Dealer: "<<D<<" > Player: "<<S<<endl;     
                        cout<<"You Lose! The Dealer wins!"<<endl; }      
                else if(D==S && D>=17){     
                        cout<<"Dealer: "<<D<<" = Player: "<<S<<endl;     
                        cout<<"You push!"<<endl;}      
                else if(D<S && D>=17){     
                        cout<<"Dealer: "<<D<<" < Player: "<<S<<endl;     
                        cout<<"Congratulations! You Win!"<<endl;}  
                        return D;  
            }  
} 

//First card given to player if hit 
/****************************************************************************** 
  *                             Player1                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Show the results of the player choosing to hit                 * 
  *             Out put the user's new sum, if over 21 show bust, if over 21  * 
  *            with ace subtract 10 from the sum and show new sum             * 
  *   Return: Sum                                                             * 
  *///*************************************************************************  
int Player1(int a[],string b[],int S,int D, char C){  
    cout<<"You got a "<<b[4]<<endl;//if bust statement      
            S= a[0]+a[2]+a[4];   
            if(S<=21){  
            cout<<"Your new sum is "<<S<<endl; }  
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)) && (S>21)){   
                S=S-10;  
                cout<<"Your new total is "<<S<<endl;  
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl;  
                        }  
                        }     
            else if(S>21){     
                    cout<<"Your new total is "<<S<<endl;  
                    cout<<"Sorry you went over 21, you busted!"<<endl;}   
            return S;  
}  
 
//Second card given to player if hit  
/****************************************************************************** 
  *                             Player2                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Show the results of the player choosing to hit                 * 
  *             Out put the user's new sum, if over 21 show bust, if over 21  * 
  *            with ace subtract 10 from the sum and show new sum             * 
  *   Return: Sum                                                             * 
  *///*************************************************************************  
int Player2(int a[],string b[],int S,int D, char C){  
    cout<<"You got a "<<b[5]<<endl;//if bust statement      
            S= a[0]+a[2]+a[4]+a[5];   
            if(S<=21){  
            cout<<"Your new sum is "<<S<<endl; }  
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)||(a[5]==11)) && (S>21)){  
                S=S-10;  
                cout<<"Your new total is "<<S<<endl;  
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl;  
                        }  
                        }     
            else if(S>21){      
                    cout<<"Your new total is "<<S<<endl;  
                    cout<<"Sorry you went over 21, you busted!"<<endl;}   
            return S;  
}  

//third card given to player if hit  
/****************************************************************************** 
  *                             Player3                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Show the results of the player choosing to hit                 * 
  *             Out put the user's new sum, if over 21 show bust, if over 21  * 
  *            with ace subtract 10 from the sum and show new sum             * 
  *   Return: Sum                                                             * 
  *///*************************************************************************  
int Player3(int a[],string b[],int S,int D, char C){  
    cout<<"You got a "<<b[6]<<endl;//if bust statement      
            S= a[0]+a[2]+a[4]+a[5]+a[6];   
            if(S<=21){  
            cout<<"Your new sum is "<<S<<endl; }  
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)) && (S>21)){   
                S=S-10;  
                cout<<"Your new total is "<<S<<endl;  
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl;  
                        }   }  
            else if(S>21){    
                    cout<<"Your new total is "<<S<<endl;  
                    cout<<"Sorry you went over 21, you busted!"<<endl;}   
            return S;  
}  

//fourth card given to player if hit  
/****************************************************************************** 
  *                             Player4                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Show the results of the player choosing to hit                 * 
  *             Out put the user's new sum, if over 21 show bust, if over 21  * 
  *            with ace subtract 10 from the sum and show new sum             * 
  *   Return: Sum                                                             * 
  *///*************************************************************************  
int Player4(int a[],string b[],int S,int D, char C){  
    cout<<"You got a "<<b[7]<<endl;//if bust statement      
            S= a[0]+a[2]+a[4]+a[5]+a[6]+a[7];   
            if(S<=21){  
            cout<<"Your new sum is "<<S<<endl; }  
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)||(a[7]==11)) && (S>21)){  
                S=S-10;  
                cout<<"Your new total is "<<S<<endl;  
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl;  
                        }  
                        }     
            else if(S>21){      
                    cout<<"Your new total is "<<S<<endl;  
                    cout<<"Sorry you went over 21, you busted!"<<endl;}   
            return S;  
}  
 
//Fifth Card given to player if choice is hit  
/****************************************************************************** 
  *                             Player5                                       * 
  ***************************************************************************** 
  *   Input: RandAry, RanAryS, Sum, DlSum, Choice                             * 
  *   Purpose: Show the results of the player choosing to hit                 * 
  *             Out put the user's new sum, if over 21 show bust, if over 21  * 
  *            with ace subtract 10 from the sum and show new sum             * 
  *            If this sum is less than 21 player automatically wins due to   * 
  *             Hitting 5 times, having seven cards and still not busting     * 
  *             This playground rule was stipulated to shorten repeating code * 
  *             And Game                                                      * 
  *   Return: Sum                                                             * 
  *///*************************************************************************  
int Player5(int a[],string b[],int S,int D, char C){  
    cout<<"You got a "<<b[8]<<endl;//if bust statement      
            S= a[0]+a[2]+a[4]+a[5]+a[6]+a[7]+a[8];   
            if(S<=21){  
            cout<<"Your new sum is "<<S<<endl; }  
            else if (((a[0]==11) || (a[2]==11) || (a[4]==11)|| (a[5]==11)||(a[6]==11)||(a[7]==11)||(a[8]==11)) && (S>21)){  
                S=S-10;  
                cout<<"Your new total is "<<S<<endl;  
                if(S>21){cout<<"Sorry you went over 21, you busted!"<<endl;  
                        }  
                        }     
              
            else if(S>21){    
                    cout<<"Your new total is "<<S<<endl;  
                    cout<<"Sorry you went over 21, you busted!"<<endl;}   
            if(S<21){    
                cout<<"You were able to hit 5 times, get 6 cards, and not go over 21!"<<endl;    
                cout<<"You win by default!"<<endl;}    
            return S;  
}
/****************************************************************************** 
  *                             GameDis                                       * 
  ***************************************************************************** 
  *   Input: RAndAry, RAnAryS, SUM, DLSum, Choice                             * 
  *   Purpose: To display the game                                            * 
  *   Return: Display game                                                    * 
  *///*************************************************************************
void GameDis(int RandAry[],string RanAryS[],int Sum,int DlSum, char choice){
       Sum=DealCd1(RandAry, RanAryS, Sum);  
   if (Sum!=21){  
   DlSum=DealCd2(RandAry, RanAryS);  
   if (DlSum!=21){  
   choice=HorS();  
   Dealer0(RandAry, RanAryS, Sum, DlSum, choice);  
    if (choice=='s'){  
        DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice);  
        if(DlSum<17)  
            DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);    
            if(DlSum<17)  
                 DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);   
                    if(DlSum<17)  
                        DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);   
                            if(DlSum<17)  
                                DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);   
        }//choice 1 stay  
     
    else if (choice=='h'){//choice1 hit  
        Sum=Player1(RandAry,RanAryS,Sum, DlSum ,choice);  
        if(Sum<=21){  
            choice=HorS();//choice 2  
            if(choice=='s'){//choice 2 stay  
                //input dealer stay after second stay  
                DlSum=Dealer0(RandAry, RanAryS, Sum, DlSum, choice);
                  if(DlSum<17) 
                    DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice);  
                    if(DlSum<17)  
                        DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);    
                        if(DlSum<17)  
                             DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);   
                                if(DlSum<17)  
                                    DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);   
                                        if(DlSum<17)  
                                            DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);
                            }//choice 2 stay  
              
            else if(choice=='h'){//choice 2 hit  
                Sum=Player2(RandAry,RanAryS,Sum, DlSum ,choice);  
                    if(Sum<=21){  
                        choice=HorS();//choice 3 stay  
                        cout<<choice<<endl;  
                       if(choice=='s'){//choice 3 stay  
                       //input dealer play after 3rd stay  
                       DlSum=Dealer0(RandAry, RanAryS, Sum, DlSum, choice);
                            if(DlSum<17)
                            DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice);  
                            if(DlSum<17)  
                                DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);    
                                if(DlSum<17)  
                                     DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);   
                                        if(DlSum<17)  
                                            DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);   
                                                if(DlSum<17)  
                                                    DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);  
                                                    }//choice 3 stay  
                          
            else if(choice=='h'){//choice 3 hit  
                Sum=Player3(RandAry,RanAryS,Sum, DlSum ,choice);  
                    if(Sum<=21){   
                        choice=HorS();//choice 4  
                        cout<<choice<<endl;  
                         if(choice=='s'){//choice 4 stay  
                        //input dealer play after 4th stay  
                             DlSum=Dealer0(RandAry, RanAryS, Sum, DlSum, choice);
                                if(DlSum<17)
                                DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice);  
                                if(DlSum<17)  
                                    DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);    
                                    if(DlSum<17)  
                                         DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);   
                                            if(DlSum<17)  
                                                DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);   
                                                    if(DlSum<17)  
                                                        DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);  
                                                                }//choice 4 stay  
                                          
            else if(choice=='h'){//choice 4 hit  
                Sum=Player4(RandAry,RanAryS,Sum, DlSum ,choice);  
                    if(Sum<=21){   
                        choice=HorS();//choice 5  
                if(choice=='s'){//choice 5 stay  
                //input dealer play after 5th stay  
                    DlSum=Dealer0(RandAry, RanAryS, Sum, DlSum, choice);
                        if(DlSum<17)
                        DlSum=Dealer1(RandAry, RanAryS,Sum,DlSum, choice);  
                        if(DlSum<17)  
                            DlSum=Dealer2(RandAry, RanAryS,Sum,DlSum, choice);    
                            if(DlSum<17)  
                                 DlSum=Dealer3(RandAry, RanAryS,Sum,DlSum, choice);   
                                    if(DlSum<17)  
                                        DlSum=Dealer4(RandAry, RanAryS,Sum,DlSum, choice);   
                                            if(DlSum<17)  
                                                DlSum=Dealer5(RandAry, RanAryS,Sum,DlSum, choice);  
                                                        }//choice 5 stay  
                                          
            else if(choice=='h'){//choice 5 hit  
                Sum=Player5(RandAry,RanAryS,Sum, DlSum ,choice);  
                                  
                         }//choice 5 hit                  
                      }//fourth if sum>=21 for choice 5 function  
                    }//choice 4 hit                       
                 }//third if sum>=21 for choice 4 function        
              }//choice 3 hit  
           }// second if sum>=21 for choice 3 function   
        }//choice 2 hit  
      }// first if sum>=21 for choice 2 function   
    }//choice 1 hit  
   }//if DlSum !=21 before choice 1  
   }//DealCd2 if sum!=21  
}